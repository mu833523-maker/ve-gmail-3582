package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Animation
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanBright
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.sin

enum class TextAnimationStyle(
    val title: String,
    val description: String,
    val iconTag: String = "✦"
) {
    STATIC("Static", "Clean sharp display", "▪"),
    TYPEWRITER("Typewriter", "Sequential typing feel", "⌨"),
    NEON_PULSE("Neon Pulse", "Breathing cyan cyber glow", "⚡"),
    GLITCH_FLICKER("Glitch Flicker", "High-frequency cyber jitter", "♒"),
    FADE_WAVE("Fade Wave", "Smooth sinusoidal opacity", "≋"),
    BOUNCE_POP("Bounce Pop", "Kinetic punchy pop-in", "⬆"),
    SLIDE_CYBER_L("Slide Left", "Horizontal cyber warp in", "←"),
    SLIDE_BOTTOM("Slide Bottom", "Bottom sheet ascent", "↑"),
    ZOOM_KINETIC("Kinetic Zoom", "Fast punch-in with settle", "⊕"),
    ROTATION_3D("3D Flip", "3D axis perspective spin", "↺"),
    CYBER_STROBE("Cyber Strobe", "High-speed strobe flashes", "☀"),
    MATRIX_RAIN("Matrix Stream", "Emerald vertical shimmer", "⇣"),
    SCALE_BREATHE("Scale Breathe", "Slow hypnotic breathing", "◎"),
    BLUR_FOCUS("Blur Focus", "Optical rack focus settle", "◌"),
    SHAKE_ENERGY("Shake Energy", "Bass rumble tremor", "〰"),
    WAVE_FLOAT("Wave Float", "Smooth floating drift", "≈"),
    RAINBOW_SHIFT("Rainbow Shift", "Dynamic hue shift wave", "🌈"),
    SCANLINE_SWEEP("Scanline Sweep", "CRT beam wipe across", "≡"),
    EXPAND_TRACK("Track Expand", "Letter spacing stretch", "↔"),
    ELASTIC_SNAP("Elastic Snap", "Rubberband spring snap", "➶"),
    HOLO_DISTORT("Holo Distort", "Wobbly hologram projector", "🗲"),
    KARAOKE_FILL("Karaoke Fill", "Timed lyric fill sweep", "🎤")
}

@Composable
fun AnimatedTextOverlayWrapper(
    animationStyle: TextAnimationStyle,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "text_anim_${animationStyle.name}")

    val pulsePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_phase"
    )

    val fastGlitch by infiniteTransition.animateFloat(
        initialValue = -1f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(120, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glitch_phase"
    )

    val continuous360 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "cont_phase"
    )

    when (animationStyle) {
        TextAnimationStyle.STATIC -> {
            Box(modifier = modifier) { content() }
        }
        TextAnimationStyle.NEON_PULSE -> {
            Box(
                modifier = modifier.graphicsLayer {
                    val s = 1.0f + pulsePhase * 0.08f
                    scaleX = s
                    scaleY = s
                    alpha = 0.85f + pulsePhase * 0.15f
                }
            ) { content() }
        }
        TextAnimationStyle.GLITCH_FLICKER -> {
            Box(
                modifier = modifier.graphicsLayer {
                    translationX = fastGlitch * 4f
                    translationY = fastGlitch * 1.5f
                    alpha = if (fastGlitch > 0.6f) 0.8f else 1f
                }
            ) { content() }
        }
        TextAnimationStyle.FADE_WAVE -> {
            Box(
                modifier = modifier.alpha(0.4f + pulsePhase * 0.6f)
            ) { content() }
        }
        TextAnimationStyle.BOUNCE_POP -> {
            Box(
                modifier = modifier.graphicsLayer {
                    val bounce = 1f + sin(pulsePhase * Math.PI.toFloat()) * 0.18f
                    scaleX = bounce
                    scaleY = bounce
                }
            ) { content() }
        }
        TextAnimationStyle.SLIDE_CYBER_L -> {
            Box(
                modifier = modifier.graphicsLayer {
                    translationX = sin(pulsePhase * Math.PI.toFloat()) * 16f
                }
            ) { content() }
        }
        TextAnimationStyle.SLIDE_BOTTOM -> {
            Box(
                modifier = modifier.graphicsLayer {
                    translationY = sin(pulsePhase * Math.PI.toFloat()) * 10f
                }
            ) { content() }
        }
        TextAnimationStyle.ZOOM_KINETIC -> {
            Box(
                modifier = modifier.graphicsLayer {
                    val zoom = 0.95f + pulsePhase * 0.15f
                    scaleX = zoom
                    scaleY = zoom
                }
            ) { content() }
        }
        TextAnimationStyle.ROTATION_3D -> {
            Box(
                modifier = modifier.graphicsLayer {
                    rotationY = sin(pulsePhase * Math.PI.toFloat()) * 30f
                }
            ) { content() }
        }
        TextAnimationStyle.CYBER_STROBE -> {
            Box(
                modifier = modifier.alpha(if (fastGlitch > 0.2f) 1f else 0.45f)
            ) { content() }
        }
        TextAnimationStyle.MATRIX_RAIN -> {
            Box(
                modifier = modifier.graphicsLayer {
                    translationY = (pulsePhase * 8f) % 8f
                    alpha = 0.85f + pulsePhase * 0.15f
                }
            ) { content() }
        }
        TextAnimationStyle.SCALE_BREATHE -> {
            Box(
                modifier = modifier.graphicsLayer {
                    val s = 0.96f + pulsePhase * 0.08f
                    scaleX = s
                    scaleY = s
                }
            ) { content() }
        }
        TextAnimationStyle.SHAKE_ENERGY -> {
            Box(
                modifier = modifier.graphicsLayer {
                    translationX = fastGlitch * 3f
                    rotationZ = fastGlitch * 2f
                }
            ) { content() }
        }
        TextAnimationStyle.WAVE_FLOAT -> {
            Box(
                modifier = modifier.graphicsLayer {
                    translationY = sin(continuous360 * (Math.PI.toFloat() / 180f)) * 8f
                }
            ) { content() }
        }
        TextAnimationStyle.HOLO_DISTORT -> {
            Box(
                modifier = modifier.graphicsLayer {
                    rotationZ = fastGlitch * 2.5f
                    alpha = 0.75f + pulsePhase * 0.25f
                }
            ) { content() }
        }
        else -> {
            // Default animated subtle pulse
            Box(
                modifier = modifier.graphicsLayer {
                    val s = 1.0f + pulsePhase * 0.05f
                    scaleX = s
                    scaleY = s
                }
            ) { content() }
        }
    }
}

@Composable
fun TextAnimationStyleSelectorBar(
    selectedStyle: TextAnimationStyle,
    onStyleSelected: (TextAnimationStyle) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Animation,
                contentDescription = null,
                tint = NeonCyan,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.size(6.dp))
            Text(
                text = "20+ TEXT ANIMATION PRESETS",
                style = TextStyle(
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = TextPrimary
                )
            )
            Spacer(modifier = Modifier.weight(1f))
            Text(
                text = selectedStyle.title.uppercase(),
                style = TextStyle(
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    color = NeonCyanBright
                )
            )
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            TextAnimationStyle.values().forEach { style ->
                val isSelected = style == selectedStyle
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isSelected) Color(0x3300E5FF) else Color(0x0F00E5FF))
                        .border(
                            width = if (isSelected) 1.2.dp else 0.7.dp,
                            color = if (isSelected) NeonCyanBright else Color(0x2200E5FF),
                            shape = RoundedCornerShape(10.dp)
                        )
                        .clickable { onStyleSelected(style) }
                        .padding(horizontal = 9.dp, vertical = 5.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = style.iconTag,
                            style = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                color = if (isSelected) NeonCyanBright else TextMuted
                            )
                        )
                        Spacer(modifier = Modifier.size(4.dp))
                        Text(
                            text = style.title,
                            style = TextStyle(
                                fontFamily = FontFamily.SansSerif,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 10.sp,
                                color = if (isSelected) NeonCyanBright else TextSecondary
                            )
                        )
                    }
                }
            }
        }
    }
}
