package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.export.ExportResolution
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.DarkCosmic
import com.example.ui.theme.DarkCosmicElevated
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanBright
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun CyberExportDialog(
    isExporting: Boolean,
    exportProgress: Int,
    isSuccess: Boolean,
    exportedPath: String,
    errorMessage: String?,
    hasVideo: Boolean,
    hasAudio: Boolean,
    textOverlayCount: Int,
    onDismiss: () -> Unit,
    onStartExport: (ExportResolution) -> Unit
) {
    val haptic = LocalHapticFeedback.current
    var selectedResolution by remember { mutableStateOf(ExportResolution.RES_1080P) }

    // Smooth scale (0.9 -> 1.0) and fade in animation
    var isVisible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { isVisible = true }

    val animScale by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0.9f,
        animationSpec = tween(250, easing = FastOutSlowInEasing),
        label = "export_dialog_scale"
    )
    val animAlpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(250, easing = FastOutSlowInEasing),
        label = "export_dialog_alpha"
    )

    val dialogShape = RoundedCornerShape(24.dp)

    AlertDialog(
        onDismissRequest = {
            if (!isExporting) onDismiss()
        },
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer {
                scaleX = animScale
                scaleY = animScale
                alpha = animAlpha
            }
            .clip(dialogShape)
            .border(
                width = 1.2.dp,
                brush = Brush.linearGradient(
                    listOf(
                        NeonCyanBright,
                        Color.White.copy(alpha = 0.3f),
                        NeonCyan,
                        Color(0xFF009CB0)
                    )
                ),
                shape = dialogShape
            )
            .shadow(
                elevation = 16.dp,
                shape = dialogShape,
                ambientColor = NeonCyan.copy(alpha = 0.5f),
                spotColor = NeonCyan.copy(alpha = 0.5f)
            )
            .testTag("cyber_export_dialog"),
        containerColor = DarkCosmic,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0x3300E5FF)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Download,
                            contentDescription = "Export Video",
                            tint = NeonCyanBright,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "RENDER & EXPORT",
                            style = TextStyle(
                                fontFamily = FontFamily.SansSerif,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                letterSpacing = 1.sp,
                                color = TextPrimary
                            )
                        )
                        Text(
                            text = "MEDIA3 TRANSFORMER // 2050",
                            style = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 9.5.sp,
                                color = NeonCyan
                            )
                        )
                    }
                }

                if (!isExporting) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(Color(0x1F00E5FF))
                            .clickable(onClick = onDismiss)
                            .testTag("export_dialog_close_btn"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Summary of assets being combined: Video + Audio + Text Overlays
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(DarkCosmicElevated)
                        .border(1.dp, Color(0x3300E5FF), RoundedCornerShape(14.dp))
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Movie,
                                contentDescription = null,
                                tint = if (hasVideo) NeonCyanBright else TextMuted,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = if (hasVideo) "Video Active" else "Sample Clip",
                                style = TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.5.sp,
                                    color = if (hasVideo) TextPrimary else TextMuted
                                )
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.MusicNote,
                                contentDescription = null,
                                tint = if (hasAudio) NeonCyanBright else TextMuted,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = if (hasAudio) "Audio Stems" else "Muted",
                                style = TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.5.sp,
                                    color = if (hasAudio) TextPrimary else TextMuted
                                )
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.TextFields,
                                contentDescription = null,
                                tint = if (textOverlayCount > 0) NeonCyanBright else TextMuted,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = "$textOverlayCount Texts",
                                style = TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.5.sp,
                                    color = if (textOverlayCount > 0) TextPrimary else TextMuted
                                )
                            )
                        }
                    }
                }

                // RESOLUTION OPTIONS: 720p, 1080p (Radio Buttons)
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "EXPORT RESOLUTION",
                        style = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            letterSpacing = 1.sp,
                            color = NeonCyan
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    ExportResolution.values().forEach { res ->
                        val isSelected = selectedResolution == res
                        val itemShape = RoundedCornerShape(12.dp)

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(itemShape)
                                .background(
                                    if (isSelected) Color(0x2200E5FF) else DarkCosmicElevated
                                )
                                .border(
                                    width = if (isSelected) 1.2.dp else 1.dp,
                                    color = if (isSelected) NeonCyan else Color(0x2200E5FF),
                                    shape = itemShape
                                )
                                .selectable(
                                    selected = isSelected,
                                    onClick = {
                                        if (!isExporting) {
                                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                            selectedResolution = res
                                        }
                                    },
                                    role = Role.RadioButton,
                                    interactionSource = remember { MutableInteractionSource() },
                                    indication = ripple(color = NeonCyan)
                                )
                                .padding(horizontal = 14.dp, vertical = 10.dp)
                                .testTag("resolution_${res.name.lowercase()}"),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    RadioButton(
                                        selected = isSelected,
                                        onClick = null,
                                        colors = RadioButtonDefaults.colors(
                                            selectedColor = NeonCyanBright,
                                            unselectedColor = TextMuted
                                        ),
                                        modifier = Modifier.size(20.dp)
                                    )

                                    Spacer(modifier = Modifier.width(10.dp))

                                    Column {
                                        Text(
                                            text = res.label,
                                            style = TextStyle(
                                                fontFamily = FontFamily.SansSerif,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.5.sp,
                                                color = if (isSelected) TextPrimary else TextSecondary
                                            )
                                        )
                                        Text(
                                            text = "${res.width} x ${res.height} • MP4 H.264",
                                            style = TextStyle(
                                                fontFamily = FontFamily.Monospace,
                                                fontSize = 10.sp,
                                                color = if (isSelected) NeonCyan else TextMuted
                                            )
                                        )
                                    }
                                }

                                if (isSelected) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(Color(0x3300E5FF))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "OPTIMAL",
                                            style = TextStyle(
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 8.5.sp,
                                                color = NeonCyanBright
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // PROGRESS BAR & STATUS
                AnimatedVisibility(
                    visible = isExporting,
                    enter = fadeIn(tween(200)),
                    exit = fadeOut(tween(200))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0x1800E5FF))
                            .border(1.dp, NeonCyan.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                            .padding(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "TRANSCODING WITH MEDIA3...",
                                style = TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.5.sp,
                                    color = NeonCyanBright
                                )
                            )
                            Text(
                                text = "$exportProgress%",
                                style = TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 13.sp,
                                    color = NeonCyanBright
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Progress Bar (Neon Cyan)
                        LinearProgressIndicator(
                            progress = { exportProgress / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .testTag("export_progress_bar"),
                            color = NeonCyanBright,
                            trackColor = Color(0x3300E5FF)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "Merging video sequence, dynamic text overlays, and audio track...",
                            style = TextStyle(
                                fontFamily = FontFamily.SansSerif,
                                fontSize = 10.5.sp,
                                color = TextMuted
                            )
                        )
                    }
                }

                // SUCCESS MESSAGE CARD
                AnimatedVisibility(
                    visible = isSuccess,
                    enter = fadeIn(tween(200)),
                    exit = fadeOut(tween(200))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0x2200FF9D))
                            .border(1.dp, CyberGreen.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
                            .padding(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = CyberGreen,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "RENDER COMPLETE • SAVED TO GALLERY",
                                style = TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = CyberGreen
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "Path: $exportedPath",
                            style = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                color = TextSecondary
                            )
                        )
                    }
                }

                // ERROR NOTIFICATION
                if (errorMessage != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0x33FF2255))
                            .border(1.dp, Color(0xFFFF2255), RoundedCornerShape(12.dp))
                            .padding(10.dp)
                    ) {
                        Text(
                            text = errorMessage,
                            style = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                color = Color(0xFFFF88AA)
                            )
                        )
                    }
                }
            }
        },
        confirmButton = {
            if (isSuccess) {
                // Done button when success
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(CyberGreen)
                        .clickable {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onDismiss()
                        }
                        .padding(horizontal = 22.dp, vertical = 10.dp)
                        .testTag("export_done_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "DONE",
                        style = TextStyle(
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = Color(0xFF041219)
                        )
                    )
                }
            } else {
                // Export Button
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            brush = if (isExporting) {
                                Brush.horizontalGradient(
                                    listOf(Color(0xFF225566), Color(0xFF113344))
                                )
                            } else {
                                Brush.horizontalGradient(
                                    listOf(NeonCyanBright, NeonCyan, Color(0xFF009CB0))
                                )
                            }
                        )
                        .clickable(
                            enabled = !isExporting,
                            interactionSource = remember { MutableInteractionSource() },
                            indication = ripple(color = Color.Black)
                        ) {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onStartExport(selectedResolution)
                        }
                        .padding(horizontal = 22.dp, vertical = 10.dp)
                        .testTag("export_start_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Download,
                            contentDescription = null,
                            tint = if (isExporting) TextMuted else Color(0xFF041219),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isExporting) "EXPORTING..." else "EXPORT MP4",
                            style = TextStyle(
                                fontFamily = FontFamily.SansSerif,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.5.sp,
                                letterSpacing = 0.6.sp,
                                color = if (isExporting) TextMuted else Color(0xFF041219)
                            )
                        )
                    }
                }
            }
        },
        dismissButton = {
            if (!isSuccess && !isExporting) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0x1800E5FF))
                        .border(1.dp, Color(0x3300E5FF), RoundedCornerShape(14.dp))
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = ripple(color = NeonCyan)
                        ) {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onDismiss()
                        }
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                        .testTag("export_cancel_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "CANCEL",
                        style = TextStyle(
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                    )
                }
            }
        }
    )
}
