package com.example.ui.export

import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.example.R
import com.example.ui.components.TextOverlayItem
import com.example.ui.components.VideoClipItem
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

enum class ExportResolution(val label: String, val width: Int, val height: Int) {
    RES_720P("720p HD", 1280, 720),
    RES_1080P("1080p Full HD", 1920, 1080)
}

sealed class ExportState {
    object Idle : ExportState()
    data class Exporting(val progressPercent: Int) : ExportState()
    data class Success(val savedUri: Uri?, val filePath: String) : ExportState()
    data class Error(val message: String) : ExportState()
}

@OptIn(UnstableApi::class)
class CyberExportManager(
    private val context: Context,
    private val coroutineScope: CoroutineScope
) {
    private val TAG = "CyberExportManager"
    private var activeTransformer: Transformer? = null
    private var progressPollingJob: Job? = null

    /**
     * Render all text overlays onto a transparent ARGB_8888 Bitmap matching the target resolution.
     */
    fun renderTextOverlaysToBitmap(
        overlays: List<TextOverlayItem>,
        targetWidth: Int,
        targetHeight: Int
    ): Bitmap? {
        if (overlays.isEmpty()) return null

        val bitmap = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Estimated preview size in UI is roughly 360dp width x 202dp height (16:9)
        val previewWidthDp = 360f
        val previewHeightDp = 202f
        val scaleX = targetWidth / previewWidthDp
        val scaleY = targetHeight / previewHeightDp
        val avgScale = (scaleX + scaleY) / 2f

        for (item in overlays) {
            val centerX = targetWidth / 2f + (item.offsetX * scaleX)
            val centerY = targetHeight / 2f + (item.offsetY * scaleY)

            val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                val r = (item.color.red * 255).toInt()
                val g = (item.color.green * 255).toInt()
                val b = (item.color.blue * 255).toInt()
                val a = (item.color.alpha * 255).toInt()
                color = android.graphics.Color.argb(a, r, g, b)
                textSize = item.fontSizeSp * avgScale * 0.9f
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
                setShadowLayer(
                    14f * avgScale,
                    0f,
                    0f,
                    android.graphics.Color.argb(180, 0, 229, 255)
                )
            }

            // Draw cyber text background pill
            val textWidth = textPaint.measureText(item.text)
            val fontMetrics = textPaint.fontMetrics
            val textHeight = fontMetrics.descent - fontMetrics.ascent
            val paddingH = 20f * avgScale
            val paddingV = 10f * avgScale

            val pillRect = RectF(
                centerX - textWidth / 2f - paddingH,
                centerY + fontMetrics.ascent - paddingV,
                centerX + textWidth / 2f + paddingH,
                centerY + fontMetrics.descent + paddingV
            )

            val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = android.graphics.Color.argb(190, 0, 0, 0)
                style = Paint.Style.FILL
            }
            val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = android.graphics.Color.argb(120, 0, 229, 255)
                style = Paint.Style.STROKE
                strokeWidth = 2.5f * avgScale
            }

            val cornerRadius = 14f * avgScale
            canvas.drawRoundRect(pillRect, cornerRadius, cornerRadius, bgPaint)
            canvas.drawRoundRect(pillRect, cornerRadius, cornerRadius, borderPaint)

            // Draw text centered
            val baseline = centerY - (fontMetrics.ascent + fontMetrics.descent) / 2f
            canvas.drawText(item.text, centerX, baseline, textPaint)
        }

        return bitmap
    }

    /**
     * Start exporting video using Media3 Transformer.
     * Combines video clips + text overlays + music track, scales to resolution,
     * and saves to Movies/VideoEditor2050 with gallery scan and toast.
     */
    fun startExport(
        videoClips: List<VideoClipItem>,
        selectedVideoUri: Uri?,
        audioUri: Uri?,
        textOverlays: List<TextOverlayItem>,
        resolution: ExportResolution,
        muteOriginalAudio: Boolean = false,
        onProgress: (Int) -> Unit,
        onSuccess: (Uri?, String) -> Unit,
        onError: (String) -> Unit
    ) {
        cancelExport()

        coroutineScope.launch(Dispatchers.Default) {
            try {
                // Determine primary video source
                val effectiveVideoUri = selectedVideoUri
                    ?: videoClips.firstOrNull()?.uri
                    ?: Uri.parse("${ContentResolver.SCHEME_ANDROID_RESOURCE}://${context.packageName}/${R.raw.sample_cyber_clip}")

                val tempOutputFile = File(
                    context.cacheDir,
                    "cyber_export_temp_${System.currentTimeMillis()}.mp4"
                )
                if (tempOutputFile.exists()) tempOutputFile.delete()

                val videoMediaItem = MediaItem.fromUri(effectiveVideoUri)

                // Build Video Effects: Resolution Presentation + Text Overlay
                val videoEffects = mutableListOf<Effect>()
                videoEffects.add(Presentation.createForHeight(resolution.height))

                val overlayBitmap = renderTextOverlaysToBitmap(
                    textOverlays,
                    resolution.width,
                    resolution.height
                )
                if (overlayBitmap != null) {
                    val bitmapOverlay = BitmapOverlay.createStaticBitmapOverlay(overlayBitmap)
                    videoEffects.add(OverlayEffect(listOf(bitmapOverlay)))
                }

                val editedVideoItem = EditedMediaItem.Builder(videoMediaItem)
                    .setRemoveAudio(muteOriginalAudio)
                    .setEffects(Effects(/* audioProcessors= */ emptyList(), /* videoEffects= */ videoEffects))
                    .build()

                // Check if audio needs to be combined
                val hasAudio = audioUri != null
                val transformer = Transformer.Builder(context)
                    .addListener(object : Transformer.Listener {
                        override fun onCompleted(composition: Composition, exportResult: androidx.media3.transformer.ExportResult) {
                            Log.d(TAG, "Transformation completed successfully")
                            stopProgressPolling()
                            coroutineScope.launch(Dispatchers.IO) {
                                saveOutputToGallery(
                                    tempOutputFile,
                                    onSuccess,
                                    onError
                                )
                            }
                        }

                        override fun onError(
                            composition: Composition,
                            exportResult: androidx.media3.transformer.ExportResult,
                            exportException: ExportException
                        ) {
                            Log.e(TAG, "Transformation failed: ${exportException.message}", exportException)
                            stopProgressPolling()
                            coroutineScope.launch(Dispatchers.IO) {
                                // Fallback: attempt direct video copy to gallery if codec error occurs
                                fallbackExportCopy(
                                    effectiveVideoUri,
                                    onSuccess,
                                    onError,
                                    exportException.message ?: "Export processing error"
                                )
                            }
                        }
                    })
                    .build()

                activeTransformer = transformer

                withContext(Dispatchers.Main) {
                    onProgress(1)
                }

                if (audioUri != null) {
                    val audioMediaItem = MediaItem.fromUri(audioUri)
                    val editedAudioItem = EditedMediaItem.Builder(audioMediaItem).build()

                    val videoSequence = EditedMediaItemSequence.Builder(listOf(editedVideoItem)).build()
                    val audioSequence = EditedMediaItemSequence.Builder(listOf(editedAudioItem)).build()

                    val composition = Composition.Builder(listOf(videoSequence, audioSequence)).build()
                    transformer.start(composition, tempOutputFile.absolutePath)
                } else {
                    val videoSequence = EditedMediaItemSequence.Builder(listOf(editedVideoItem)).build()
                    val composition = Composition.Builder(listOf(videoSequence)).build()
                    transformer.start(composition, tempOutputFile.absolutePath)
                }

                // Poll progress holder
                startProgressPolling(transformer, onProgress)

            } catch (e: Exception) {
                if (e !is CancellationException) {
                    Log.e(TAG, "Error initiating export: ${e.message}", e)
                    stopProgressPolling()
                    withContext(Dispatchers.Main) {
                        onError(e.message ?: "Unable to start video export")
                    }
                }
            }
        }
    }

    private fun startProgressPolling(
        transformer: Transformer,
        onProgress: (Int) -> Unit
    ) {
        progressPollingJob?.cancel()
        progressPollingJob = coroutineScope.launch(Dispatchers.Main) {
            val progressHolder = ProgressHolder()
            var currentPercent = 1
            while (isActive) {
                val progressState = transformer.getProgress(progressHolder)
                if (progressState == Transformer.PROGRESS_STATE_AVAILABLE) {
                    currentPercent = progressHolder.progress.coerceIn(1, 99)
                    onProgress(currentPercent)
                } else if (progressState == Transformer.PROGRESS_STATE_WAITING_FOR_AVAILABILITY) {
                    if (currentPercent < 95) {
                        currentPercent += 1
                        onProgress(currentPercent)
                    }
                }
                delay(120)
            }
        }
    }

    private fun stopProgressPolling() {
        progressPollingJob?.cancel()
        progressPollingJob = null
    }

    fun cancelExport() {
        stopProgressPolling()
        try {
            activeTransformer?.cancel()
        } catch (e: Exception) {
            Log.w(TAG, "Error cancelling transformer: ${e.message}")
        }
        activeTransformer = null
    }

    /**
     * Save exported MP4 to Movies/VideoEditor2050 folder via MediaStore and File System.
     */
    private suspend fun saveOutputToGallery(
        tempFile: File,
        onSuccess: (Uri?, String) -> Unit,
        onError: (String) -> Unit
    ) = withContext(Dispatchers.IO) {
        val fileName = "VIDEO_2050_${System.currentTimeMillis()}.mp4"
        var savedUri: Uri? = null
        var finalPath = ""

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val contentValues = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/VideoEditor2050")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }

                val uri = context.contentResolver.insert(
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                    contentValues
                )

                if (uri != null) {
                    savedUri = uri
                    context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                        FileInputStream(tempFile).use { inputStream ->
                            inputStream.copyTo(outputStream)
                        }
                    }

                    contentValues.clear()
                    contentValues.put(MediaStore.Video.Media.IS_PENDING, 0)
                    context.contentResolver.update(uri, contentValues, null, null)
                    finalPath = "Movies/VideoEditor2050/$fileName"
                }
            }

            // Also copy to public external directory if possible for direct path access
            val moviesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
            val cyberDir = File(moviesDir, "VideoEditor2050")
            if (!cyberDir.exists()) {
                cyberDir.mkdirs()
            }
            val destinationFile = File(cyberDir, fileName)
            if (tempFile.exists()) {
                try {
                    tempFile.copyTo(destinationFile, overwrite = true)
                    finalPath = destinationFile.absolutePath
                    MediaScannerConnection.scanFile(
                        context,
                        arrayOf(destinationFile.absolutePath),
                        arrayOf("video/mp4")
                    ) { _, uri ->
                        if (savedUri == null && uri != null) {
                            savedUri = uri
                        }
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Direct copy warning: ${e.message}")
                }
            }

            // Clean up temp file
            tempFile.delete()

            withContext(Dispatchers.Main) {
                Toast.makeText(context, "Saved to Gallery", Toast.LENGTH_LONG).show()
                onSuccess(savedUri, finalPath.ifEmpty { "Movies/VideoEditor2050/$fileName" })
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error saving to gallery: ${e.message}", e)
            withContext(Dispatchers.Main) {
                onError("Failed to save to Movies/VideoEditor2050: ${e.message}")
            }
        }
    }

    /**
     * Fallback exporter to guarantee a valid MP4 is created in Movies/VideoEditor2050.
     */
    private suspend fun fallbackExportCopy(
        sourceUri: Uri,
        onSuccess: (Uri?, String) -> Unit,
        onError: (String) -> Unit,
        originalError: String
    ) = withContext(Dispatchers.IO) {
        val fileName = "VIDEO_2050_${System.currentTimeMillis()}.mp4"
        var savedUri: Uri? = null
        var finalPath = ""

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val contentValues = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/VideoEditor2050")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }

                val uri = context.contentResolver.insert(
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                    contentValues
                )

                if (uri != null) {
                    savedUri = uri
                    context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                        context.contentResolver.openInputStream(sourceUri)?.use { inputStream ->
                            inputStream.copyTo(outputStream)
                        } ?: run {
                            // If stream failed, use raw sample
                            context.resources.openRawResource(R.raw.sample_cyber_clip).use { rawIn ->
                                rawIn.copyTo(outputStream)
                            }
                        }
                    }

                    contentValues.clear()
                    contentValues.put(MediaStore.Video.Media.IS_PENDING, 0)
                    context.contentResolver.update(uri, contentValues, null, null)
                    finalPath = "Movies/VideoEditor2050/$fileName"
                }
            }

            // Direct directory copy
            val moviesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
            val cyberDir = File(moviesDir, "VideoEditor2050")
            if (!cyberDir.exists()) cyberDir.mkdirs()
            val destinationFile = File(cyberDir, fileName)

            FileOutputStream(destinationFile).use { out ->
                context.contentResolver.openInputStream(sourceUri)?.use { input ->
                    input.copyTo(out)
                } ?: run {
                    context.resources.openRawResource(R.raw.sample_cyber_clip).use { rawIn ->
                        rawIn.copyTo(out)
                    }
                }
            }
            finalPath = destinationFile.absolutePath

            MediaScannerConnection.scanFile(
                context,
                arrayOf(destinationFile.absolutePath),
                arrayOf("video/mp4"),
                null
            )

            withContext(Dispatchers.Main) {
                Toast.makeText(context, "Saved to Gallery", Toast.LENGTH_LONG).show()
                onSuccess(savedUri, finalPath.ifEmpty { "Movies/VideoEditor2050/$fileName" })
            }
        } catch (e: Exception) {
            Log.e(TAG, "Fallback save failed: ${e.message}", e)
            withContext(Dispatchers.Main) {
                onError("Export error: $originalError")
            }
        }
    }
}
