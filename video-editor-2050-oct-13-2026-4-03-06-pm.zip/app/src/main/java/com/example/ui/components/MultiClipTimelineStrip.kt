package com.example.ui.components

import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.ViewCarousel
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.material3.ripple
import androidx.compose.runtime.remember
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkCosmic
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanBright
import com.example.ui.theme.NeonCyanDark
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.UUID

data class VideoClipItem(
    val id: String = UUID.randomUUID().toString(),
    val uri: Uri,
    val name: String,
    val durationMs: Long,
    val thumbnail: ImageBitmap? = null
)

/**
 * Cyberpunk 2050 Multi-Clip Timeline Strip
 * Displays all picked video clips in a horizontal scrollable row with thumbnails,
 * duration badges, active neon cyan border, individual X delete buttons, and a '+' add clip button.
 */
@Composable
fun MultiClipTimelineStrip(
    clips: List<VideoClipItem>,
    selectedClipId: String?,
    onSelectClip: (VideoClipItem) -> Unit,
    onRemoveClip: (String) -> Unit,
    onAddClip: () -> Unit,
    isBeatSyncActive: Boolean = false,
    onAutoCutBeats: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val containerShape = RoundedCornerShape(24.dp)
    val scrollState = rememberScrollState()

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(containerShape)
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0x2800E5FF),
                        Color(0x1A09141F),
                        Color(0x33000000)
                    )
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        NeonCyan.copy(alpha = 0.5f),
                        Color.White.copy(alpha = 0.15f),
                        NeonCyan.copy(alpha = 0.4f)
                    )
                ),
                shape = containerShape
            )
            .padding(vertical = 10.dp, horizontal = 12.dp)
            .testTag("multi_clip_timeline_strip")
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Header Row: Track Title & Clip Count & Beat Sync
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 4.dp, end = 4.dp, bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.ViewCarousel,
                        contentDescription = "Multi-Clip",
                        tint = NeonCyan,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "MULTI-CLIP TIMELINE",
                        style = TextStyle(
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            letterSpacing = 1.sp,
                            color = TextPrimary
                        )
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (isBeatSyncActive) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0x33FF007F))
                                .border(0.8.dp, Color(0xFFFF007F), RoundedCornerShape(6.dp))
                                .clickable(onClick = onAutoCutBeats)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "⚡ AUTO-CUT BEATS",
                                style = TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 8.5.sp,
                                    color = Color(0xFFFF80BF)
                                )
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                    }

                    // Total clips badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0x2600E5FF))
                            .border(0.8.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 7.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "${clips.size} CLIPS",
                            style = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.sp,
                                color = NeonCyanBright
                            )
                        )
                    }
                }
            }

            // Horizontal Scrollable Clips Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(scrollState),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                clips.forEachIndexed { index, clip ->
                    val isSelected = clip.id == selectedClipId
                    ClipThumbnailCard(
                        clip = clip,
                        index = index + 1,
                        isSelected = isSelected,
                        onClick = { onSelectClip(clip) },
                        onRemove = { onRemoveClip(clip.id) }
                    )
                }

                // "+" Add More Clips Button
                Box(
                    modifier = Modifier
                        .size(width = 68.dp, height = 72.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0x1F00E5FF))
                        .border(
                            width = 1.2.dp,
                            brush = Brush.linearGradient(
                                listOf(NeonCyanBright, NeonCyanDark)
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )
                        .clickable(onClick = onAddClip)
                        .testTag("add_clip_timeline_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(Color(0x3300E5FF)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Add Clip",
                                tint = NeonCyanBright,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "ADD",
                            style = TextStyle(
                                fontFamily = FontFamily.SansSerif,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                letterSpacing = 0.8.sp,
                                color = NeonCyan
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ClipThumbnailCard(
    clip: VideoClipItem,
    index: Int,
    isSelected: Boolean,
    onClick: () -> Unit,
    onRemove: () -> Unit
) {
    val cardShape = RoundedCornerShape(12.dp)
    val totalSeconds = (clip.durationMs / 1000).coerceAtLeast(0)
    val durationText = String.format("%02d:%02d", totalSeconds / 60, totalSeconds % 60)

    Box(
        modifier = Modifier
            .size(width = 96.dp, height = 72.dp)
            .shadow(
                elevation = if (isSelected) 10.dp else 2.dp,
                shape = cardShape,
                ambientColor = if (isSelected) NeonCyan else Color.Transparent,
                spotColor = if (isSelected) NeonCyan else Color.Transparent
            )
            .clip(cardShape)
            .background(Color(0xFF03070A))
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                brush = if (isSelected) {
                    Brush.linearGradient(
                        listOf(NeonCyanBright, NeonCyan, Color.White, NeonCyanBright)
                    )
                } else {
                    Brush.linearGradient(
                        listOf(Color(0x3300E5FF), Color(0x1A00E5FF))
                    )
                },
                shape = cardShape
            )
            .clickable(onClick = onClick)
            .testTag("clip_card_${clip.id}"),
        contentAlignment = Alignment.Center
    ) {
        // Thumbnail Image or Cyber Placeholder
        if (clip.thumbnail != null) {
            Image(
                bitmap = clip.thumbnail,
                contentDescription = "Clip $index",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            // Shading overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x33000000))
            )
        } else {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = NeonCyan.copy(alpha = 0.6f),
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = "CLIP $index",
                    style = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        color = TextMuted
                    )
                )
            }
        }

        // Top-left Track Index Pill
        Box(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(4.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(Color(0xCC051420))
                .padding(horizontal = 4.dp, vertical = 2.dp)
        ) {
            Text(
                text = "#$index",
                style = TextStyle(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 9.sp,
                    color = if (isSelected) NeonCyanBright else TextSecondary
                )
            )
        }

        // Top-right Delete Button (X)
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(3.dp)
                .size(18.dp)
                .clip(CircleShape)
                .background(Color(0xDDCC1133))
                .clickable(onClick = onRemove)
                .testTag("remove_clip_${clip.id}"),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Remove clip",
                tint = Color.White,
                modifier = Modifier.size(11.dp)
            )
        }

        // Bottom Corner Duration Badge
        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(4.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(Color(0xDD000000))
                .padding(horizontal = 4.dp, vertical = 2.dp)
        ) {
            Text(
                text = durationText,
                style = TextStyle(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 8.5.sp,
                    color = NeonCyan
                )
            )
        }
    }
}
