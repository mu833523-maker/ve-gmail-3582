package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanBright
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

/**
 * Easy visual guide dialog designed specifically so that anyone,
 * even with zero technical knowledge or low literacy, can understand
 * every tool in 5 seconds via emojis and plain, friendly words.
 */
@Composable
fun EasyVisualGuideDialog(
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .clip(RoundedCornerShape(26.dp))
                .background(Color(0xFF070E18))
                .border(1.5.dp, NeonCyanBright, RoundedCornerShape(26.dp))
                .padding(20.dp)
                .testTag("easy_visual_guide_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0x3300E5FF))
                                .border(1.dp, NeonCyanBright, RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lightbulb,
                                contentDescription = null,
                                tint = NeonCyanBright,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "💡 आसान गाइड (Easy Guide)",
                                style = TextStyle(
                                    fontFamily = FontFamily.SansSerif,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = TextPrimary
                                )
                            )
                            Text(
                                text = "हर बटन का काम आसानी से समझें",
                                style = TextStyle(
                                    fontFamily = FontFamily.SansSerif,
                                    fontSize = 11.sp,
                                    color = NeonCyan
                                )
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(Color(0x2200E5FF))
                            .clickable { onDismiss() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Visual Step-by-Step Cards
                GuideFeatureRow(
                    emoji = "✂️",
                    name = "काटें (Cut & Trim)",
                    desc = "वीडियो को छोटा करें, फ़ालतू हिस्सा हटाएं या बीच से दो टुकड़े करें।"
                )

                Spacer(modifier = Modifier.height(10.dp))

                GuideFeatureRow(
                    emoji = "🔇",
                    name = "शोर हटाएं (Remove Noise)",
                    desc = "पंखा, गाड़ी, हवा और बाहर का शोर 1-क्लिक में हटाएं और आवाज़ बिल्कुल साफ़ करें।"
                )

                Spacer(modifier = Modifier.height(10.dp))

                GuideFeatureRow(
                    emoji = "🗣️",
                    name = "आवाज़ क्लोन (Voice Clone 10k)",
                    desc = "अपनी आवाज़ का सैंपल दें, और फिर 10 से 10,000 शब्द तक कुछ भी लिखवाएं — आपकी ही आवाज़ बोलेगी!"
                )

                Spacer(modifier = Modifier.height(10.dp))

                GuideFeatureRow(
                    emoji = "🎵",
                    name = "गाना जोड़ें (Music & Audio)",
                    desc = "अपने मोबाइल से कोई भी गाना या बैकग्राउंड धुन वीडियो में लगाएं।"
                )

                Spacer(modifier = Modifier.height(10.dp))

                GuideFeatureRow(
                    emoji = "🎨",
                    name = "रंग और फ़िल्टर (Filters)",
                    desc = "वीडियो को गोरा, ब्राइट और सिनेमाई रंग दें (50+ फ़िल्टर)।"
                )

                Spacer(modifier = Modifier.height(10.dp))

                GuideFeatureRow(
                    emoji = "📝",
                    name = "लिखें (Text & Titles)",
                    desc = "वीडियो के ऊपर सुंदर नाम, शायरी या डायलॉग लिखें।"
                )

                Spacer(modifier = Modifier.height(10.dp))

                GuideFeatureRow(
                    emoji = "⚡",
                    name = "रफ़्तार (Speed / Slow-Mo)",
                    desc = "वीडियो को स्लो-मोशन (धीमा) या फ़ास्ट (तेज़) बनाएं।"
                )

                Spacer(modifier = Modifier.height(10.dp))

                GuideFeatureRow(
                    emoji = "📥",
                    name = "सेव करें (Save to Gallery)",
                    desc = "पूरा वीडियो 1-क्लिक में सीधे अपने फ़ोन की गैलरी में सेव करें!"
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Big "Got it" button
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            Brush.horizontalGradient(
                                listOf(
                                    NeonCyan,
                                    NeonCyanBright
                                )
                            )
                        )
                        .clickable { onDismiss() },
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = Color.Black,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "समझ गया (Start Editing)",
                            style = TextStyle(
                                fontFamily = FontFamily.SansSerif,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = Color.Black
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun GuideFeatureRow(
    emoji: String,
    name: String,
    desc: String
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0x1200E5FF))
            .border(0.8.dp, Color(0x2800E5FF), RoundedCornerShape(14.dp))
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = emoji,
                fontSize = 24.sp
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = name,
                    style = TextStyle(
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = NeonCyanBright
                    )
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = desc,
                    style = TextStyle(
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 11.5.sp,
                        color = TextSecondary,
                        lineHeight = 16.sp
                    )
                )
            }
        }
    }
}
