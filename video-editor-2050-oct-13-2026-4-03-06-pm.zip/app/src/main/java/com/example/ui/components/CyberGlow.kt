package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.outlined.DashboardCustomize
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberViolet
import com.example.ui.theme.DarkCosmic
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanBright
import com.example.ui.theme.TextPrimary
import kotlin.random.Random

/**
 * Deep cosmic background (#050505) with soft ambient glow, subtle cyber grid,
 * and procedural cinematic grain/noise texture.
 */
@Composable
fun CosmicCyberBackground(
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height

        // Deep cosmic base (#050505)
        drawRect(color = DarkCosmic)

        // Soft ambient cyan halo (gentle, diffuse, not sharp)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    NeonCyan.copy(alpha = 0.08f),
                    NeonCyan.copy(alpha = 0.02f),
                    Color.Transparent
                ),
                center = Offset(width * 0.5f, height * 0.16f),
                radius = width * 0.85f
            ),
            radius = width * 0.85f,
            center = Offset(width * 0.5f, height * 0.16f)
        )

        // Soft ambient violet flare in bottom-right corner
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    CyberViolet.copy(alpha = 0.07f),
                    CyberViolet.copy(alpha = 0.015f),
                    Color.Transparent
                ),
                center = Offset(width * 0.85f, height * 0.86f),
                radius = width * 0.8f
            ),
            radius = width * 0.8f,
            center = Offset(width * 0.85f, height * 0.86f)
        )

        // Subtle, elegant sci-fi grid
        val step = 56.dp.toPx()
        val gridAlpha = 0.025f
        var x = 0f
        while (x < width) {
            drawLine(
                color = NeonCyan.copy(alpha = gridAlpha),
                start = Offset(x, 0f),
                end = Offset(x, height),
                strokeWidth = 0.75f
            )
            x += step
        }
        var y = 0f
        while (y < height) {
            drawLine(
                color = NeonCyan.copy(alpha = gridAlpha),
                start = Offset(0f, y),
                end = Offset(width, y),
                strokeWidth = 0.75f
            )
            y += step
        }

        // Cinematic grain / film stipple texture
        val rng = Random(42)
        val numGrains = 400
        for (i in 0 until numGrains) {
            val gx = rng.nextFloat() * width
            val gy = rng.nextFloat() * height
            val gAlpha = 0.035f + rng.nextFloat() * 0.03f
            drawCircle(
                color = Color.White.copy(alpha = gAlpha),
                radius = 1.2f,
                center = Offset(gx, gy)
            )
        }
    }
}

/**
 * Premium elegant title: Minimalist Apple-like style.
 * Solid soft white (#E8E8E8) with no glow and a subtle cyan underline bar (2dp height, 60dp width, 0.6 opacity).
 */
@Composable
fun NeonGlowingTitle(
    title: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = title,
            style = TextStyle(
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Bold,
                fontSize = 28.sp,
                letterSpacing = 2.2.sp,
                color = Color(0xFFE8E8E8),
                textAlign = TextAlign.Center
            )
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Subtle cyan underline bar (2dp height, 60dp width, soft opacity 0.6)
        Box(
            modifier = Modifier
                .width(60.dp)
                .height(2.dp)
                .clip(RoundedCornerShape(1.dp))
                .background(Color(0xFF00E5FF).copy(alpha = 0.6f))
        )
    }
}

/**
 * Big glowing "NEW PROJECT" button with gentle, slow breathing pulse (2.6s)
 * and 24dp rounded corners.
 */
@Composable
fun NeonPulseNewProjectButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "btn_slow_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.995f,
        targetValue = 1.018f,
        animationSpec = infiniteRepeatable(
            animation = tween(2600, easing = FastOutSlowInEasing), // Gentle 2.6s pulse
            repeatMode = RepeatMode.Reverse
        ),
        label = "btn_pulse_scale"
    )
    val haloAlpha by infiniteTransition.animateFloat(
        initialValue = 0.22f,
        targetValue = 0.48f,
        animationSpec = infiniteRepeatable(
            animation = tween(2600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "btn_halo_alpha"
    )

    val shape = RoundedCornerShape(24.dp)
    val interactionSource = remember { MutableInteractionSource() }
    val haptic = LocalHapticFeedback.current

    Box(
        modifier = modifier
            .fillMaxWidth()
            .scale(pulseScale),
        contentAlignment = Alignment.Center
    ) {
        // Soft ambient halo around button
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(68.dp)
        ) {
            drawRoundRect(
                color = NeonCyan.copy(alpha = haloAlpha * 0.4f),
                size = size,
                cornerRadius = CornerRadius(28.dp.toPx(), 28.dp.toPx())
            )
        }

        // Core elegant button (24dp rounded corners)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp)
                .clip(shape)
                .background(
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            NeonCyanBright,
                            NeonCyan,
                            Color(0xFF00B4D8)
                        )
                    )
                )
                .border(
                    width = 1.2.dp,
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.6f),
                            NeonCyanBright,
                            Color.White.copy(alpha = 0.6f)
                        )
                    ),
                    shape = shape
                )
                .clickable(
                    interactionSource = interactionSource,
                    indication = ripple(color = Color.White),
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onClick()
                    }
                )
                .testTag("new_project_button"),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 24.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF04141E)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "New Project Icon",
                        tint = NeonCyanBright,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column {
                    Text(
                        text = "NEW PROJECT",
                        style = TextStyle(
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 15.sp,
                            letterSpacing = 1.sp,
                            color = Color(0xFF041219)
                        )
                    )
                    Text(
                        text = "नई वीडियो बनाएं (Asaan Video Edit)",
                        style = TextStyle(
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 10.sp,
                            color = Color(0xFF072733)
                        )
                    )
                }
            }
        }
    }
}

/**
 * Secondary button "TEMPLATES" with glassmorphism style and 24dp rounded corners.
 */
@Composable
fun GlassmorphismTemplatesButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(24.dp)
    val interactionSource = remember { MutableInteractionSource() }
    val haptic = LocalHapticFeedback.current

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(56.dp)
            .clip(shape)
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0x1F00E5FF),
                        Color(0x0F00E5FF),
                        Color(0x08000000)
                    )
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        NeonCyan.copy(alpha = 0.5f),
                        Color.White.copy(alpha = 0.15f),
                        NeonCyan.copy(alpha = 0.35f)
                    )
                ),
                shape = shape
            )
            .clickable(
                interactionSource = interactionSource,
                indication = ripple(color = NeonCyan),
                onClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onClick()
                }
            )
            .testTag("templates_button"),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 24.dp)
        ) {
            Icon(
                imageVector = Icons.Outlined.DashboardCustomize,
                contentDescription = "Templates Icon",
                tint = NeonCyan,
                modifier = Modifier.size(19.dp)
            )

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Text(
                    text = "READY TEMPLATES",
                    style = TextStyle(
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.5.sp,
                        letterSpacing = 1.sp,
                        color = TextPrimary
                    )
                )
                Text(
                    text = "बने बनाए डिज़ाइन (Direct Use)",
                    style = TextStyle(
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 9.5.sp,
                        color = NeonCyan
                    )
                )
            }
        }
    }
}

/**
 * Reusable Glassmorphic Card with 24dp rounded corners.
 */
@Composable
fun GlassmorphicCard(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val shape = RoundedCornerShape(24.dp)
    Box(
        modifier = modifier
            .clip(shape)
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0x1700E5FF),
                        Color(0x0A00E5FF),
                        Color(0x12080D14)
                    )
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        NeonCyan.copy(alpha = 0.45f),
                        Color.White.copy(alpha = 0.08f),
                        NeonCyan.copy(alpha = 0.25f)
                    )
                ),
                shape = shape
            )
            .padding(20.dp)
    ) {
        content()
    }
}
