package com.example.ui.components

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberPink
import com.example.ui.theme.DarkCosmic
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanBright
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.sin

/**
 * Noise Level Preset options - simple for anyone to understand
 */
enum class NoiseReductionPreset(
    val title: String,
    val hindiTitle: String,
    val iconEmoji: String,
    val description: String,
    val percent: Float
) {
    MILD("Mild Clean", "हल्का (कम शोर)", "🍃", "Removes room fan, AC & slight hum", 0.50f),
    MEDIUM("Medium Clean", "मध्यम (हवा/ट्रैफिक)", "🚗", "Removes street traffic & wind noise", 0.80f),
    PRO_MAX("Studio Clean", "100% साफ़ (स्टूडियो आवाज़)", "🎙️", "Isolates pure human voice, zero noise", 1.0f)
}

/**
 * CyberNoiseRemoverDialog: 1-Tap Voice Background Noise Remover & Vocal Isolator
 * Super friendly for non-tech / illiterate users with visual emoji cues.
 */
@Composable
fun CyberNoiseRemoverDialog(
    isNoiseRemovalActive: Boolean,
    currentReductionLevel: Float,
    videoClipName: String? = null,
    onApplyNoiseRemoval: (Boolean, Float) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()

    var isEnabled by remember { mutableStateOf(isNoiseRemovalActive) }
    var reductionLevel by remember { mutableFloatStateOf(currentReductionLevel.coerceIn(0.2f, 1.0f)) }
    var selectedPreset by remember {
        mutableStateOf(
            when {
                reductionLevel >= 0.9f -> NoiseReductionPreset.PRO_MAX
                reductionLevel >= 0.65f -> NoiseReductionPreset.MEDIUM
                else -> NoiseReductionPreset.MILD
            }
        )
    }

    // Audio test preview state
    var isTestingAudio by remember { mutableStateOf(false) }
    var isComparingOriginal by remember { mutableStateOf(false) }
    var isProcessingAi by remember { mutableStateOf(false) }

    // Waveform animation
    val infiniteTransition = rememberInfiniteTransition(label = "noise_anim")
    val waveAnimPhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1100, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "phase"
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .clip(RoundedCornerShape(26.dp))
                .background(Color(0xFF070E16))
                .border(1.5.dp, if (isEnabled) CyberGreen else NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(26.dp))
                .padding(20.dp)
                .testTag("noise_remover_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // Header with big icons and dual language
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isEnabled) Color(0x3300FF9D) else Color(0x2200E5FF))
                                .border(1.dp, if (isEnabled) CyberGreen else NeonCyan, RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isEnabled) Icons.AutoMirrored.Filled.VolumeOff else Icons.Default.Hearing,
                                contentDescription = null,
                                tint = if (isEnabled) CyberGreen else NeonCyanBright,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "🔇 आवाज़ से शोर हटाएं",
                                style = TextStyle(
                                    fontFamily = FontFamily.SansSerif,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = TextPrimary
                                )
                            )
                            Text(
                                text = "REMOVE BACKGROUND NOISE • CLEAN VOCALS",
                                style = TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 9.sp,
                                    color = if (isEnabled) CyberGreen else NeonCyan
                                )
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(Color(0x2200E5FF))
                            .clickable { onDismiss() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Big Master Toggle Card: "शोर हटाएं (Denoise) ON / OFF"
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(if (isEnabled) Color(0x2000FF9D) else Color(0x1200E5FF))
                        .border(
                            1.2.dp,
                            if (isEnabled) CyberGreen else Color(0x3500E5FF),
                            RoundedCornerShape(18.dp)
                        )
                        .clickable {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            isEnabled = !isEnabled
                        }
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = if (isEnabled) "✅" else "⚪",
                                fontSize = 24.sp
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = if (isEnabled) "आवाज़ साफ़ करना चालू है (ON)" else "शोर हटाना बंद है (OFF)",
                                    style = TextStyle(
                                        fontFamily = FontFamily.SansSerif,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = if (isEnabled) CyberGreen else TextSecondary
                                    )
                                )
                                Text(
                                    text = if (isEnabled) "पंखा, हवा, गाड़ी का शोर हटेगा" else "ओरिजिनल आवाज़ जैसी थी वैसी रहेगी",
                                    style = TextStyle(
                                        fontFamily = FontFamily.SansSerif,
                                        fontSize = 11.sp,
                                        color = TextMuted
                                    )
                                )
                            }
                        }

                        Switch(
                            checked = isEnabled,
                            onCheckedChange = {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                isEnabled = it
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.Black,
                                checkedTrackColor = CyberGreen,
                                uncheckedThumbColor = Color.Gray,
                                uncheckedTrackColor = Color(0x30FFFFFF)
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Visual Waveform Animation Comparison
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF040910))
                        .border(1.dp, Color(0x2500E5FF), RoundedCornerShape(16.dp))
                        .padding(14.dp)
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isEnabled && !isComparingOriginal) "🟢 साफ़ आवाज़ (CLEAN VOCAL)" else "🔴 शोर वाली आवाज़ (NOISY ORIGINAL)",
                                style = TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.5.sp,
                                    color = if (isEnabled && !isComparingOriginal) CyberGreen else CyberPink
                                )
                            )

                            // 1-Tap A/B Comparison Toggle
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isComparingOriginal) CyberPink.copy(alpha = 0.25f) else Color(0x2200E5FF))
                                    .border(0.8.dp, if (isComparingOriginal) CyberPink else NeonCyan, RoundedCornerShape(8.dp))
                                    .clickable {
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        isComparingOriginal = !isComparingOriginal
                                    }
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = if (isComparingOriginal) "सुन रहे हैं: ओरिजिनल 🔊" else "फ़र्क सुनें (A/B Test)",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isComparingOriginal) CyberPink else NeonCyanBright
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Waveform Visualizer
                        NoiseWaveformCanvas(
                            isClean = isEnabled && !isComparingOriginal,
                            reductionLevel = reductionLevel,
                            wavePhase = waveAnimPhase,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // 3 Simple Presets for Everyone
                Text(
                    text = "आवाज़ कितनी साफ़ करनी है? (Select Clean Level):",
                    style = TextStyle(
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = TextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    NoiseReductionPreset.values().forEach { preset ->
                        val isSelected = selectedPreset == preset
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(
                                    if (isSelected) Color(0x3000FF9D) else Color(0x0E00E5FF)
                                )
                                .border(
                                    width = if (isSelected) 1.5.dp else 0.8.dp,
                                    color = if (isSelected) CyberGreen else Color(0x2500E5FF),
                                    shape = RoundedCornerShape(14.dp)
                                )
                                .clickable {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    selectedPreset = preset
                                    reductionLevel = preset.percent
                                    isEnabled = true
                                }
                                .padding(vertical = 10.dp, horizontal = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(preset.iconEmoji, fontSize = 22.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = preset.hindiTitle,
                                    style = TextStyle(
                                        fontFamily = FontFamily.SansSerif,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        fontSize = 10.5.sp,
                                        color = if (isSelected) CyberGreen else TextPrimary,
                                        textAlign = TextAlign.Center
                                    )
                                )
                                Text(
                                    text = "${(preset.percent * 100).toInt()}%",
                                    style = TextStyle(
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 9.sp,
                                        color = if (isSelected) CyberGreen else TextMuted
                                    )
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Fine Tuning Slider
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0x0C00E5FF))
                        .border(0.8.dp, Color(0x2000E5FF), RoundedCornerShape(14.dp))
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "मैन्युअल कंट्रोल (Fine Tune Slider)",
                            style = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 11.sp, color = TextSecondary)
                        )
                        Text(
                            text = "${(reductionLevel * 100).toInt()}% साफ़",
                            style = TextStyle(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = CyberGreen)
                        )
                    }

                    Slider(
                        value = reductionLevel,
                        onValueChange = {
                            reductionLevel = it
                            isEnabled = true
                        },
                        valueRange = 0.2f..1.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = CyberGreen,
                            activeTrackColor = CyberGreen,
                            inactiveTrackColor = Color(0x3000E5FF)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Action Buttons: Cancel & Apply
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Close button
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0x1800E5FF))
                            .border(1.dp, Color(0x3500E5FF), RoundedCornerShape(14.dp))
                            .clickable { onDismiss() },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "रद्द करें (Cancel)",
                            style = TextStyle(
                                fontFamily = FontFamily.SansSerif,
                                fontWeight = FontWeight.Medium,
                                fontSize = 12.sp,
                                color = TextMuted
                            )
                        )
                    }

                    // Apply Button: 1-Tap Save
                    Box(
                        modifier = Modifier
                            .weight(1.5f)
                            .height(48.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                Brush.horizontalGradient(
                                    listOf(
                                        CyberGreen,
                                        Color(0xFF00E676)
                                    )
                                )
                            )
                            .clickable {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                onApplyNoiseRemoval(isEnabled, reductionLevel)
                                Toast.makeText(
                                    context,
                                    if (isEnabled) "✅ आवाज़ से शोर हटा दिया गया! (Noise Removed)" else "ओरिजिनल आवाज़ बहाल की गई",
                                    Toast.LENGTH_SHORT
                                ).show()
                                onDismiss()
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = Color.Black,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "लागू करें (APPLY)",
                                style = TextStyle(
                                    fontFamily = FontFamily.SansSerif,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = Color.Black
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Animated Waveform showing noisy jagged audio vs clean smooth vocal wave
 */
@Composable
private fun NoiseWaveformCanvas(
    isClean: Boolean,
    reductionLevel: Float,
    wavePhase: Float,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val barCount = 42
        val barWidth = size.width / (barCount * 1.5f)
        val centerY = size.height / 2f

        for (i in 0 until barCount) {
            val x = i * (size.width / barCount) + barWidth / 2f
            val baseSin = sin((i * 0.35f + wavePhase * 6.28f).toDouble()).toFloat()

            val barHeight = if (isClean) {
                // Clean vocal curve: smooth harmonic peaks in center, zero erratic noise at ends
                val centerWeight = 1f - (kotlin.math.abs(i - barCount / 2f) / (barCount / 2f))
                val vocalPeak = (0.25f + centerWeight * 0.70f) * kotlin.math.abs(baseSin)
                (vocalPeak * size.height * 0.85f).coerceAtLeast(4f)
            } else {
                // Noisy erratic jagged spikes throughout
                val randomJitter = (sin((i * 1.8f + wavePhase * 4f).toDouble()).toFloat() * 0.4f)
                val noisySpike = (kotlin.math.abs(baseSin) * 0.6f + kotlin.math.abs(randomJitter) * 0.4f)
                (noisySpike * size.height * 0.95f).coerceAtLeast(6f)
            }

            val barColor = if (isClean) {
                CyberGreen
            } else {
                if (i % 2 == 0) CyberPink else Color(0xFFFF5252)
            }

            drawRoundRect(
                color = barColor,
                topLeft = Offset(x - barWidth / 2f, centerY - barHeight / 2f),
                size = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f)
            )
        }
    }
}
