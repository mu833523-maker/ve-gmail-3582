package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberPink
import com.example.ui.theme.CyberViolet
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanBright
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

/**
 * Interactive Cyberpunk 2050 Trim & Cut Timeline component.
 * Allows dual-handle trimming (start/end) and live playback scrubbing.
 */
@Composable
fun CyberTrimTimeline(
    currentPositionMs: Long,
    totalDurationMs: Long,
    trimStartMs: Long,
    trimEndMs: Long,
    isPlaying: Boolean,
    onPlayPauseToggle: () -> Unit,
    onSeekTo: (Long) -> Unit,
    onTrimChange: (startMs: Long, endMs: Long) -> Unit,
    onResetTrim: () -> Unit,
    modifier: Modifier = Modifier
) {
    val durationSafe = if (totalDurationMs > 0) totalDurationMs else 1L
    val startFraction = (trimStartMs.toFloat() / durationSafe).coerceIn(0f, 1f)
    val endFraction = (trimEndMs.toFloat() / durationSafe).coerceIn(startFraction + 0.05f, 1f)
    val playheadFraction = (currentPositionMs.toFloat() / durationSafe).coerceIn(0f, 1f)

    GlassmorphicCard(
        modifier = modifier.testTag("trim_timeline_card")
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Header with Trim Metadata
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0x3300E5FF)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCut,
                            contentDescription = "Trim",
                            tint = NeonCyanBright,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "TIMELINE TRIM",
                        style = TextStyle(
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            letterSpacing = 1.sp,
                            color = TextPrimary
                        )
                    )
                }

                // Trimmed Duration Badge
                val trimmedDuration = (trimEndMs - trimStartMs).coerceAtLeast(0)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0x2800E5FF))
                        .border(1.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "CLIP: ${formatTimeMs(trimmedDuration)}",
                        style = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            color = NeonCyanBright
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Cyber Filmstrip / Waveform Timeline Canvas
            var timelineWidthPx by remember { mutableFloatStateOf(1f) }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF03070A))
                    .border(1.dp, Color(0x3300E5FF), RoundedCornerShape(10.dp))
                    .pointerInput(totalDurationMs) {
                        detectTapGestures { offset ->
                            val width = size.width.toFloat()
                            if (width > 0) {
                                val targetFraction = (offset.x / width).coerceIn(0f, 1f)
                                onSeekTo((targetFraction * durationSafe).toLong())
                            }
                        }
                    }
            ) {
                Canvas(modifier = Modifier.matchParentSize()) {
                    timelineWidthPx = size.width
                    val width = size.width
                    val height = size.height

                    // Draw faux video frames / cyber wave bars
                    val barWidth = 4.dp.toPx()
                    val barSpacing = 7.dp.toPx()
                    var x = 4.dp.toPx()
                    var i = 0
                    while (x < width - barWidth) {
                        // Procedural waveform height pattern
                        val heightMultiplier = when (i % 6) {
                            0 -> 0.35f
                            1 -> 0.65f
                            2 -> 0.85f
                            3 -> 0.55f
                            4 -> 0.95f
                            else -> 0.45f
                        }
                        val barHeight = height * 0.6f * heightMultiplier
                        val top = (height - barHeight) / 2f

                        val inTrimRegion = x >= (startFraction * width) && x <= (endFraction * width)
                        val barColor = if (inTrimRegion) {
                            NeonCyan.copy(alpha = 0.65f)
                        } else {
                            Color(0x33455A64)
                        }

                        drawRoundRect(
                            color = barColor,
                            topLeft = Offset(x, top),
                            size = Size(barWidth, barHeight),
                            cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
                        )

                        x += barSpacing
                        i++
                    }

                    // Shaded excluded regions (left of trim start)
                    val startX = startFraction * width
                    val endX = endFraction * width

                    if (startX > 0) {
                        drawRect(
                            color = Color(0xB3000000),
                            topLeft = Offset(0f, 0f),
                            size = Size(startX, height)
                        )
                    }

                    // Shaded excluded regions (right of trim end)
                    if (endX < width) {
                        drawRect(
                            color = Color(0xB3000000),
                            topLeft = Offset(endX, 0f),
                            size = Size(width - endX, height)
                        )
                    }

                    // Active trim box border
                    drawRect(
                        brush = Brush.horizontalGradient(
                            listOf(NeonCyanBright, NeonCyan, NeonCyanBright)
                        ),
                        topLeft = Offset(startX, 0f),
                        size = Size(endX - startX, height),
                        style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.dp.toPx())
                    )

                    // Draw Left Trim Handle Bar
                    drawRoundRect(
                        color = NeonCyanBright,
                        topLeft = Offset(startX - 2.dp.toPx(), 0f),
                        size = Size(7.dp.toPx(), height),
                        cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx())
                    )

                    // Draw Right Trim Handle Bar
                    drawRoundRect(
                        color = NeonCyanBright,
                        topLeft = Offset(endX - 5.dp.toPx(), 0f),
                        size = Size(7.dp.toPx(), height),
                        cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx())
                    )

                    // Draw live playhead needle
                    val playheadX = playheadFraction * width
                    drawLine(
                        color = Color.White,
                        start = Offset(playheadX, 0f),
                        end = Offset(playheadX, height),
                        strokeWidth = 2.5.dp.toPx()
                    )
                    drawCircle(
                        color = NeonCyanBright,
                        radius = 4.dp.toPx(),
                        center = Offset(playheadX, 5.dp.toPx())
                    )
                }

                // Interactive drag handle overlay for Start Trim
                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .pointerInput(totalDurationMs) {
                            detectDragGestures { change, dragAmount ->
                                change.consume()
                                val width = size.width.toFloat()
                                if (width > 0) {
                                    val currentX = (change.position.x).coerceIn(0f, width)
                                    val fraction = currentX / width
                                    val newStartMs = (fraction * durationSafe).toLong()
                                    if (newStartMs < trimEndMs - 500L) {
                                        onTrimChange(newStartMs.coerceAtLeast(0L), trimEndMs)
                                        onSeekTo(newStartMs.coerceAtLeast(0L))
                                    }
                                }
                            }
                        }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Timestamps row: [Start timestamp] [Current Playhead] [End timestamp]
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "IN: ${formatTimeMs(trimStartMs)}",
                    style = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = NeonCyan
                    )
                )

                Text(
                    text = "${formatTimeMs(currentPositionMs)} / ${formatTimeMs(totalDurationMs)}",
                    style = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                )

                Text(
                    text = "OUT: ${formatTimeMs(trimEndMs)}",
                    style = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = NeonCyan
                    )
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Quick Playback & Trim Action Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Set Start at Current Position
                TrimActionButton(
                    icon = Icons.Default.SkipPrevious,
                    label = "SET START",
                    onClick = {
                        if (currentPositionMs < trimEndMs) {
                            onTrimChange(currentPositionMs, trimEndMs)
                        }
                    }
                )

                // Play / Pause Toggle
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(
                            brush = Brush.radialGradient(
                                colors = listOf(NeonCyanBright, NeonCyan, Color(0xFF009CB0))
                            )
                        )
                        .clickable { onPlayPauseToggle() }
                        .testTag("timeline_play_pause_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (isPlaying) "Pause" else "Play",
                        tint = Color(0xFF041219),
                        modifier = Modifier.size(24.dp)
                    )
                }

                // Set End at Current Position
                TrimActionButton(
                    icon = Icons.Default.SkipNext,
                    label = "SET END",
                    onClick = {
                        if (currentPositionMs > trimStartMs) {
                            onTrimChange(trimStartMs, currentPositionMs)
                        }
                    }
                )

                // Reset Trim
                TrimActionButton(
                    icon = Icons.Default.Replay,
                    label = "RESET",
                    onClick = onResetTrim
                )
            }
        }
    }
}

@Composable
private fun TrimActionButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0x1A00E5FF))
            .border(1.dp, Color(0x3300E5FF), RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = NeonCyan,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                style = TextStyle(
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    letterSpacing = 0.5.sp,
                    color = TextSecondary
                )
            )
        }
    }
}

fun formatTimeMs(millis: Long): String {
    val totalSeconds = (millis / 1000).coerceAtLeast(0)
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    val tenths = (millis % 1000) / 100
    return String.format(Locale.US, "%02d:%02d.%d", minutes, seconds, tenths)
}
