package com.example.ui.components

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberPink
import com.example.ui.theme.CyberViolet
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanBright
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.sin
import kotlin.random.Random

enum class CyberSfxType(
    val title: String,
    val category: String,
    val durationDesc: String,
    val iconTag: String = "♫"
) {
    WHOOSH_TRANSITION("Cinematic Whoosh", "Motion", "0.6s", "💨"),
    CYBER_GLITCH("Glitch Zap", "Cyber", "0.4s", "⚡"),
    LASER_BEAM("Laser Pulse", "Sci-Fi", "0.5s", "✨"),
    BASS_DROP_808("808 Bass Impact", "Bass", "1.2s", "💣"),
    NEON_HUM("Resonant Hum", "Ambient", "0.8s", "♒"),
    SCIFI_UI_BEEP("Neural Beep", "UI", "0.2s", "🔘"),
    CAMERA_SHUTTER("Camera Click", "UI", "0.3s", "📸"),
    REWIND_TAPE("Tape Rewind", "Retro", "0.7s", "📼"),
    CYBER_HEARTBEAT("Pulse Thump", "Suspense", "0.8s", "💓"),
    QUANTUM_RISER("Synth Riser", "Impact", "1.0s", "📈"),
    VICTORY_CHIME("Level Chime", "Game", "0.6s", "🔔"),
    TACTILE_CLICK("Tactile Switch", "UI", "0.15s", "🖲")
}

object CyberSoundSynthesizer {
    private const val SAMPLE_RATE = 44100

    fun playSfx(type: CyberSfxType) {
        CoroutineScope(Dispatchers.Default).launch {
            try {
                val samples = generateSamples(type)
                playPcm(samples)
            } catch (e: Exception) {
                Log.e("CyberSfx", "Error synthesizing sound: ${e.message}")
            }
        }
    }

    private fun generateSamples(type: CyberSfxType): ShortArray {
        return when (type) {
            CyberSfxType.WHOOSH_TRANSITION -> {
                val duration = 0.55f
                val count = (SAMPLE_RATE * duration).toInt()
                val buffer = ShortArray(count)
                for (i in 0 until count) {
                    val progress = i.toFloat() / count
                    val freq = 200f + 1100f * sin(progress * Math.PI.toFloat())
                    val envelope = sin(progress * Math.PI.toFloat())
                    val sample = sin(2 * Math.PI * freq * i / SAMPLE_RATE) * envelope * 0.75f
                    buffer[i] = (sample * Short.MAX_VALUE).toInt().toShort()
                }
                buffer
            }
            CyberSfxType.CYBER_GLITCH -> {
                val duration = 0.35f
                val count = (SAMPLE_RATE * duration).toInt()
                val buffer = ShortArray(count)
                var currentFreq = 800f
                for (i in 0 until count) {
                    if (i % 800 == 0) {
                        currentFreq = 300f + Random.nextFloat() * 1800f
                    }
                    val envelope = 1f - (i.toFloat() / count)
                    val noise = (Random.nextFloat() * 2f - 1f) * 0.25f
                    val tone = sin(2 * Math.PI * currentFreq * i / SAMPLE_RATE).toFloat() * 0.6f
                    val sample = (tone + noise) * envelope
                    buffer[i] = (sample * Short.MAX_VALUE).toInt().toShort()
                }
                buffer
            }
            CyberSfxType.LASER_BEAM -> {
                val duration = 0.45f
                val count = (SAMPLE_RATE * duration).toInt()
                val buffer = ShortArray(count)
                for (i in 0 until count) {
                    val progress = i.toFloat() / count
                    val freq = 2200f * (1f - progress * 0.85f)
                    val envelope = (1f - progress) * (1f - progress)
                    val sample = sin(2 * Math.PI * freq * i / SAMPLE_RATE) * envelope * 0.85f
                    buffer[i] = (sample * Short.MAX_VALUE).toInt().toShort()
                }
                buffer
            }
            CyberSfxType.BASS_DROP_808 -> {
                val duration = 1.1f
                val count = (SAMPLE_RATE * duration).toInt()
                val buffer = ShortArray(count)
                for (i in 0 until count) {
                    val progress = i.toFloat() / count
                    val freq = 160f * Math.pow(0.25, progress.toDouble()).toFloat() + 35f
                    val envelope = Math.exp(-progress.toDouble() * 3.5).toFloat()
                    val sample = sin(2 * Math.PI * freq * i / SAMPLE_RATE) * envelope * 0.95f
                    buffer[i] = (sample * Short.MAX_VALUE).toInt().toShort()
                }
                buffer
            }
            CyberSfxType.SCIFI_UI_BEEP -> {
                val duration = 0.18f
                val count = (SAMPLE_RATE * duration).toInt()
                val buffer = ShortArray(count)
                for (i in 0 until count) {
                    val progress = i.toFloat() / count
                    val envelope = 1f - progress
                    val sample = sin(2 * Math.PI * 1760.0 * i / SAMPLE_RATE) * envelope * 0.6f
                    buffer[i] = (sample * Short.MAX_VALUE).toInt().toShort()
                }
                buffer
            }
            CyberSfxType.CAMERA_SHUTTER -> {
                val duration = 0.25f
                val count = (SAMPLE_RATE * duration).toInt()
                val buffer = ShortArray(count)
                for (i in 0 until count) {
                    val progress = i.toFloat() / count
                    val click = if (progress < 0.2f || (progress in 0.5f..0.7f)) {
                        (Random.nextFloat() * 2f - 1f) * 0.8f
                    } else {
                        0f
                    }
                    buffer[i] = (click * Short.MAX_VALUE).toInt().toShort()
                }
                buffer
            }
            else -> {
                // Harmonic Synth Rise
                val duration = 0.5f
                val count = (SAMPLE_RATE * duration).toInt()
                val buffer = ShortArray(count)
                for (i in 0 until count) {
                    val progress = i.toFloat() / count
                    val freq = 440f + progress * 440f
                    val envelope = sin(progress * Math.PI.toFloat())
                    val sample = sin(2 * Math.PI * freq * i / SAMPLE_RATE) * envelope * 0.65f
                    buffer[i] = (sample * Short.MAX_VALUE).toInt().toShort()
                }
                buffer
            }
        }
    }

    private fun playPcm(samples: ShortArray) {
        val minBuf = AudioTrack.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .build()
            )
            .setBufferSizeInBytes(Math.max(minBuf, samples.size * 2))
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()

        track.write(samples, 0, samples.size)
        track.play()
    }
}

@Composable
fun CyberSoundEffectsBar(
    onSfxAttached: (CyberSfxType) -> Unit,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current
    var activeSfx by remember { mutableStateOf<CyberSfxType?>(null) }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.verticalGradient(
                    listOf(Color(0x2800E5FF), Color(0x12080E16), Color(0x2E000000))
                )
            )
            .border(1.dp, NeonCyan.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
            .padding(12.dp)
            .testTag("cyber_sfx_bar")
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.VolumeUp,
                        contentDescription = null,
                        tint = NeonCyanBright,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "10+ CYBER SFX LIBRARY",
                        style = TextStyle(
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.5.sp,
                            letterSpacing = 1.sp,
                            color = TextPrimary
                        )
                    )
                }

                Text(
                    text = "TAP TO PREVIEW & ATTACH",
                    style = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        color = TextMuted
                    )
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CyberSfxType.values().forEach { sfx ->
                    val isPlaying = activeSfx == sfx
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isPlaying) Color(0x3500E5FF) else Color(0x1000E5FF))
                            .border(
                                width = if (isPlaying) 1.2.dp else 0.8.dp,
                                color = if (isPlaying) NeonCyanBright else Color(0x2800E5FF),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                activeSfx = sfx
                                CyberSoundSynthesizer.playSfx(sfx)
                                onSfxAttached(sfx)
                            }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = sfx.iconTag,
                                fontSize = 13.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text(
                                    text = sfx.title,
                                    style = TextStyle(
                                        fontFamily = FontFamily.SansSerif,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 10.5.sp,
                                        color = if (isPlaying) NeonCyanBright else TextPrimary
                                    )
                                )
                                Text(
                                    text = "${sfx.category} • ${sfx.durationDesc}",
                                    style = TextStyle(
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 8.5.sp,
                                        color = TextSecondary
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
