package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberPink
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanBright
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

/**
 * CapCut-Style Instant Quick Action Bar
 * Designed with large icons, emojis, and dual Hindi/English labels so anyone
 * can understand and operate every single feature easily with 1-tap.
 */
@Composable
fun CapCutQuickActionBar(
    isOriginalMuted: Boolean,
    playbackSpeed: Float,
    hasVideo: Boolean,
    onSplitCut: () -> Unit,
    onToggleMute: () -> Unit,
    onQuickSpeed: () -> Unit,
    onAddMusic: () -> Unit,
    onOpenVoice: () -> Unit,
    onAddText: () -> Unit,
    onOpenFilters: () -> Unit,
    onSaveVideo: () -> Unit,
    onOpenNoiseRemover: () -> Unit = {},
    isNoiseRemoved: Boolean = false,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current
    val scrollState = rememberScrollState()

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0B141E),
                        Color(0xFF050B12)
                    )
                )
            )
            .border(1.dp, Color(0x3500E5FF), RoundedCornerShape(20.dp))
            .padding(vertical = 10.dp, horizontal = 10.dp)
            .testTag("capcut_quick_action_bar")
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Friendly guide label
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("⚡", fontSize = 12.sp)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "1-Tap Quick Tools",
                        style = TextStyle(
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = NeonCyanBright
                        )
                    )
                }
                Text(
                    text = "Scroll Right 👉",
                    style = TextStyle(
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 10.sp,
                        color = TextMuted
                    )
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Horizontally scrollable quick action buttons
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(scrollState),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 1. Cut / Split
                QuickActionItem(
                    emoji = "✂️",
                    title = "Cut",
                    sub = "Split",
                    icon = Icons.Default.ContentCut,
                    accentColor = NeonCyanBright,
                    testTag = "quick_cut_btn",
                    onClick = onSplitCut
                )

                // 2. Noise Remover / Clean Voice
                QuickActionItem(
                    emoji = "🔇",
                    title = if (isNoiseRemoved) "Cleaned" else "Clean Noise",
                    sub = "Clear Voice",
                    icon = Icons.AutoMirrored.Filled.VolumeOff,
                    accentColor = if (isNoiseRemoved) CyberGreen else Color(0xFF00E5FF),
                    isActive = isNoiseRemoved,
                    testTag = "quick_noise_btn",
                    onClick = onOpenNoiseRemover
                )

                // 3. Voice Cloner & 10,000 words
                QuickActionItem(
                    emoji = "🗣️",
                    title = "Voice Clone",
                    sub = "AI Cloner",
                    icon = Icons.Default.Mic,
                    accentColor = CyberGreen,
                    testTag = "quick_voice_btn",
                    onClick = onOpenVoice
                )

                // 4. Mute / Unmute
                QuickActionItem(
                    emoji = if (isOriginalMuted) "🔇" else "🔊",
                    title = if (isOriginalMuted) "Mute" else "Volume",
                    sub = if (isOriginalMuted) "Muted" else "Sound ON",
                    icon = if (isOriginalMuted) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                    accentColor = if (isOriginalMuted) CyberPink else NeonCyanBright,
                    isActive = isOriginalMuted,
                    testTag = "quick_mute_btn",
                    onClick = onToggleMute
                )

                // 5. Speed
                val speedLabel = if (playbackSpeed == 1.0f) "1x" else "${playbackSpeed}x"
                QuickActionItem(
                    emoji = "⚡",
                    title = "Speed",
                    sub = speedLabel,
                    icon = Icons.Default.Speed,
                    accentColor = Color(0xFFFFD166),
                    testTag = "quick_speed_btn",
                    onClick = onQuickSpeed
                )

                // 6. Music / Audio
                QuickActionItem(
                    emoji = "🎵",
                    title = "Music",
                    sub = "Audio",
                    icon = Icons.Default.MusicNote,
                    accentColor = Color(0xFF06D6A0),
                    testTag = "quick_music_btn",
                    onClick = onAddMusic
                )

                // 7. Filters / Color
                QuickActionItem(
                    emoji = "🎨",
                    title = "Filters",
                    sub = "Color",
                    icon = Icons.Default.AutoFixHigh,
                    accentColor = Color(0xFFEF476F),
                    testTag = "quick_filters_btn",
                    onClick = onOpenFilters
                )

                // 8. Text
                QuickActionItem(
                    emoji = "📝",
                    title = "Text",
                    sub = "Titles",
                    icon = Icons.Default.TextFields,
                    accentColor = NeonCyan,
                    testTag = "quick_text_btn",
                    onClick = onAddText
                )

                // 9. Save Video
                QuickActionItem(
                    emoji = "📥",
                    title = "Export",
                    sub = "Save MP4",
                    icon = Icons.Default.Download,
                    accentColor = CyberGreen,
                    isSaveAction = true,
                    testTag = "quick_save_btn",
                    onClick = onSaveVideo
                )
            }
        }
    }
}

@Composable
private fun QuickActionItem(
    emoji: String,
    title: String,
    sub: String,
    icon: ImageVector,
    accentColor: Color,
    isActive: Boolean = false,
    isSaveAction: Boolean = false,
    testTag: String,
    onClick: () -> Unit
) {
    val haptic = LocalHapticFeedback.current
    val itemShape = RoundedCornerShape(14.dp)

    Box(
        modifier = Modifier
            .clip(itemShape)
            .then(
                if (isSaveAction) {
                    Modifier.background(Brush.verticalGradient(listOf(CyberGreen.copy(alpha = 0.35f), Color(0x2000FF9D))))
                } else if (isActive) {
                    Modifier.background(accentColor.copy(alpha = 0.25f))
                } else {
                    Modifier.background(Color(0x1800E5FF))
                }
            )
            .border(
                width = if (isSaveAction || isActive) 1.5.dp else 0.8.dp,
                color = if (isSaveAction) CyberGreen else if (isActive) accentColor else Color(0x3000E5FF),
                shape = itemShape
            )
            .clickable(
                indication = ripple(color = accentColor),
                interactionSource = remember { MutableInteractionSource() }
            ) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            }
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = emoji, fontSize = 14.sp)
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = if (isSaveAction) CyberGreen else accentColor,
                    modifier = Modifier.size(16.dp)
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = title,
                style = TextStyle(
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.5.sp,
                    color = if (isSaveAction) CyberGreen else TextPrimary,
                    textAlign = TextAlign.Center
                )
            )

            Text(
                text = sub,
                style = TextStyle(
                    fontFamily = FontFamily.SansSerif,
                    fontSize = 9.5.sp,
                    color = TextMuted,
                    textAlign = TextAlign.Center
                )
            )
        }
    }
}
