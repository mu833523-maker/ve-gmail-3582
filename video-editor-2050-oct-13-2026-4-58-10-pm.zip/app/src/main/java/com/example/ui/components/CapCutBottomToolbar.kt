package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.CallSplit
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberPink
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanBright
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

enum class CapCutToolbarMode {
    MAIN,
    EDIT_SUBMENU
}

/**
 * CapCut Bottom Toolbar with Big Icons and Simple One-Word Labels
 * Level 1: Edit, Audio, Text, Stickers, Effects, Filters, Voice, Export
 * Level 2 (Edit Submenu): Split, Speed, Volume, Delete, Duplicate, Rotate
 */
@Composable
fun CapCutBottomToolbar(
    mode: CapCutToolbarMode,
    activeMainTool: String = "Edit",
    onSwitchMode: (CapCutToolbarMode) -> Unit,
    // Main actions
    onEditClick: () -> Unit,
    onAudioClick: () -> Unit,
    onTextClick: () -> Unit,
    onStickersClick: () -> Unit,
    onEffectsClick: () -> Unit,
    onFiltersClick: () -> Unit,
    onVoiceClick: () -> Unit,
    onExportClick: () -> Unit,
    // Edit submenu actions
    onSplitClick: () -> Unit,
    onSpeedClick: () -> Unit,
    onVolumeClick: () -> Unit,
    onDeleteClick: () -> Unit,
    onDuplicateClick: () -> Unit,
    onRotateClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current

    Box(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
            .background(Color(0xFF070B10))
            .border(
                1.dp,
                Color(0x2800E5FF),
                RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
            )
            .padding(vertical = 8.dp)
            .testTag("capcut_bottom_toolbar")
    ) {
        AnimatedContent(
            targetState = mode,
            transitionSpec = {
                if (targetState == CapCutToolbarMode.EDIT_SUBMENU) {
                    slideInHorizontally { it } + fadeIn() togetherWith slideOutHorizontally { -it } + fadeOut()
                } else {
                    slideInHorizontally { -it } + fadeIn() togetherWith slideOutHorizontally { it } + fadeOut()
                }
            },
            label = "ToolbarModeTransition"
        ) { currentMode ->
            if (currentMode == CapCutToolbarMode.MAIN) {
                // LEVEL 1: MAIN TOOLBAR
                val scrollState = rememberScrollState()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(scrollState)
                        .padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CapCutToolButton(
                        label = "Edit",
                        icon = Icons.Default.ContentCut,
                        isSelected = activeMainTool == "Edit",
                        accentColor = NeonCyanBright,
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onEditClick()
                            onSwitchMode(CapCutToolbarMode.EDIT_SUBMENU)
                        }
                    )

                    CapCutToolButton(
                        label = "Audio",
                        icon = Icons.Default.MusicNote,
                        isSelected = activeMainTool == "Audio",
                        accentColor = Color(0xFF06D6A0),
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onAudioClick()
                        }
                    )

                    CapCutToolButton(
                        label = "Text",
                        icon = Icons.Default.TextFields,
                        isSelected = activeMainTool == "Text",
                        accentColor = Color(0xFFFFB703),
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onTextClick()
                        }
                    )

                    CapCutToolButton(
                        label = "Stickers",
                        icon = Icons.Default.LocalOffer,
                        isSelected = activeMainTool == "Stickers",
                        accentColor = Color(0xFFC77DFF),
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onStickersClick()
                        }
                    )

                    CapCutToolButton(
                        label = "Effects",
                        icon = Icons.Default.AutoFixHigh,
                        isSelected = activeMainTool == "Effects",
                        accentColor = Color(0xFFFF007F),
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onEffectsClick()
                        }
                    )

                    CapCutToolButton(
                        label = "Filters",
                        icon = Icons.Default.ColorLens,
                        isSelected = activeMainTool == "Filters",
                        accentColor = Color(0xFF00E5FF),
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onFiltersClick()
                        }
                    )

                    CapCutToolButton(
                        label = "Voice",
                        icon = Icons.Default.Mic,
                        isSelected = activeMainTool == "Voice",
                        accentColor = Color(0xFFFFD166),
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onVoiceClick()
                        }
                    )

                    CapCutToolButton(
                        label = "Export",
                        icon = Icons.Default.FileUpload,
                        isSelected = false,
                        accentColor = Color(0xFF00E5FF),
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            onExportClick()
                        }
                    )
                }
            } else {
                // LEVEL 2: EDIT SUBMENU (Split, Speed, Volume, Delete, Duplicate, Rotate)
                val editScrollState = rememberScrollState()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(editScrollState)
                        .padding(horizontal = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Back button to return to Main toolbar
                    CapCutToolButton(
                        label = "Back",
                        icon = Icons.AutoMirrored.Filled.ArrowBack,
                        isSelected = false,
                        accentColor = TextMuted,
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onSwitchMode(CapCutToolbarMode.MAIN)
                        }
                    )

                    // Vertical divider
                    Box(
                        modifier = Modifier
                            .width(1.dp)
                            .height(36.dp)
                            .background(Color(0x3000E5FF))
                    )

                    CapCutToolButton(
                        label = "Split",
                        icon = Icons.Default.CallSplit,
                        isSelected = false,
                        accentColor = NeonCyanBright,
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            onSplitClick()
                        }
                    )

                    CapCutToolButton(
                        label = "Speed",
                        icon = Icons.Default.Speed,
                        isSelected = false,
                        accentColor = Color(0xFFFFD166),
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onSpeedClick()
                        }
                    )

                    CapCutToolButton(
                        label = "Volume",
                        icon = Icons.AutoMirrored.Filled.VolumeUp,
                        isSelected = false,
                        accentColor = Color(0xFF06D6A0),
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onVolumeClick()
                        }
                    )

                    CapCutToolButton(
                        label = "Delete",
                        icon = Icons.Default.Delete,
                        isSelected = false,
                        accentColor = CyberPink,
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            onDeleteClick()
                        }
                    )

                    CapCutToolButton(
                        label = "Duplicate",
                        icon = Icons.Default.ContentCopy,
                        isSelected = false,
                        accentColor = Color(0xFFC77DFF),
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onDuplicateClick()
                        }
                    )

                    CapCutToolButton(
                        label = "Rotate",
                        icon = Icons.Default.RotateRight,
                        isSelected = false,
                        accentColor = Color(0xFF00E5FF),
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onRotateClick()
                        }
                    )
                }
            }
        }
    }
}

/**
 * Big Icon + 1-Word Label Tool Button (Min 48dp touch target)
 */
@Composable
private fun CapCutToolButton(
    label: String,
    icon: ImageVector,
    isSelected: Boolean,
    accentColor: Color,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(bounded = false, radius = 28.dp)
            ) { onClick() }
            .padding(horizontal = 6.dp, vertical = 4.dp)
            .testTag("capcut_tool_${label.lowercase()}"),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Big Icon in container
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(
                    if (isSelected) accentColor.copy(alpha = 0.25f)
                    else Color(0x1800E5FF)
                )
                .border(
                    width = if (isSelected) 1.5.dp else 0.8.dp,
                    color = if (isSelected) accentColor else Color(0x2800E5FF),
                    shape = CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isSelected) accentColor else Color.White,
                modifier = Modifier.size(24.dp)
            )
        }

        Spacer(modifier = Modifier.height(5.dp))

        // Simple One-word English label
        Text(
            text = label,
            style = TextStyle(
                fontFamily = FontFamily.SansSerif,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                fontSize = 11.5.sp,
                color = if (isSelected) accentColor else Color(0xFFE2E8F0)
            )
        )
    }
}
