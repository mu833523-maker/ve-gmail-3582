package com.example.ui.components

import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberPink
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanBright
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * CapCut-Style Horizontal Timeline
 * Features:
 * - Seconds ruler with tick marks (00:00, 00:01, 00:02...)
 * - White vertical playhead line in the middle
 * - Video clips thumbnail strips (scrollable, pinch/button zoomable)
 * - Trim handles on selected clip
 * - Separate tracks for Audio, Text, and Stickers
 * - "+" button at the end to add more videos
 */
@Composable
fun CapCutTimeline(
    videoClips: List<VideoClipItem>,
    selectedClipId: String?,
    currentPositionMs: Long,
    totalDurationMs: Long,
    trimStartMs: Long,
    trimEndMs: Long,
    isPlaying: Boolean,
    onSelectClip: (VideoClipItem) -> Unit,
    onRemoveClip: (String) -> Unit,
    onAddClip: () -> Unit,
    onSeekTo: (Long) -> Unit,
    onTrimChange: (startMs: Long, endMs: Long) -> Unit,
    onTogglePlayPause: () -> Unit,
    // Audio Track
    audioTrackName: String? = null,
    audioDurationMs: Long = 0L,
    onAddAudio: () -> Unit = {},
    onRemoveAudio: () -> Unit = {},
    // Text Track
    textOverlays: List<TextOverlayItem> = emptyList(),
    onAddText: () -> Unit = {},
    onRemoveText: (String) -> Unit = {},
    // Stickers Track
    placedStickers: List<PlacedStickerItem> = emptyList(),
    onAddSticker: () -> Unit = {},
    onRemoveSticker: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current
    val density = LocalDensity.current

    // Zoom scale: 1.0f means 60dp per second. Range 0.6f .. 2.5f
    var zoomScale by remember { mutableFloatStateOf(1.0f) }

    // Safe duration calculation
    val effectiveDurationMs = max(totalDurationMs, if (videoClips.isNotEmpty()) videoClips.sumOf { it.durationMs } else 8000L)
    val totalSeconds = (effectiveDurationMs / 1000f).coerceAtLeast(4f)

    // Base pixels per second
    val dpPerSecond = 55.dp * zoomScale
    val pxPerSecond = with(density) { dpPerSecond.toPx() }

    val timelineWidthPx = (totalSeconds * pxPerSecond).coerceAtLeast(800f)
    val timelineWidthDp = with(density) { timelineWidthPx.toDp() }

    val scrollState = rememberScrollState()

    // Sync scroll with playhead position during playback
    LaunchedEffect(currentPositionMs, isPlaying, zoomScale) {
        if (isPlaying && totalDurationMs > 0) {
            val progressFrac = (currentPositionMs.toFloat() / effectiveDurationMs).coerceIn(0f, 1f)
            val targetScroll = (progressFrac * timelineWidthPx).toInt()
            scrollState.scrollTo(targetScroll.coerceIn(0, scrollState.maxValue))
        }
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
            .background(Color(0xFF0D1117))
            .border(
                1.dp,
                Brush.verticalGradient(listOf(Color(0x4000E5FF), Color(0x1500E5FF))),
                RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
            )
            .testTag("capcut_timeline_container")
    ) {
        val containerWidthPx = with(density) { maxWidth.toPx() }
        val containerWidthDp = maxWidth
        val centerLinePx = containerWidthPx / 2f
        val centerLineDp = maxWidth / 2f

        Column(modifier = Modifier.fillMaxWidth()) {
            // TOP BAR OVER TIMELINE: Play button, timecode, and zoom buttons
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Big Play / Pause button & Current Timecode
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            onTogglePlayPause()
                        },
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(if (isPlaying) Color(0x30FF007F) else Color(0x2500E5FF))
                            .border(1.2.dp, if (isPlaying) CyberPink else NeonCyanBright, CircleShape)
                            .testTag("timeline_play_pause_button")
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) "Pause" else "Play",
                            tint = if (isPlaying) CyberPink else NeonCyanBright,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    // Timecode display: e.g. 00:02 / 00:15
                    val curSec = currentPositionMs / 1000
                    val curMs = (currentPositionMs % 1000) / 100
                    val totSec = effectiveDurationMs / 1000
                    val timeStr = String.format(Locale.US, "%02d:%01d / %02d:00", curSec, curMs, totSec)

                    Text(
                        text = timeStr,
                        style = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = TextPrimary,
                            letterSpacing = 0.8.sp
                        )
                    )
                }

                // Zoom Out / Zoom In buttons
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    IconButton(
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            zoomScale = (zoomScale - 0.25f).coerceAtLeast(0.6f)
                        },
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0x1800E5FF))
                            .border(0.8.dp, Color(0x3500E5FF), RoundedCornerShape(8.dp))
                            .testTag("timeline_zoom_out")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ZoomOut,
                            contentDescription = "Zoom Out",
                            tint = NeonCyan,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    Text(
                        text = "${(zoomScale * 100).toInt()}%",
                        style = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = TextSecondary
                        ),
                        modifier = Modifier.padding(horizontal = 2.dp)
                    )

                    IconButton(
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            zoomScale = (zoomScale + 0.25f).coerceAtMost(2.5f)
                        },
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0x1800E5FF))
                            .border(0.8.dp, Color(0x3500E5FF), RoundedCornerShape(8.dp))
                            .testTag("timeline_zoom_in")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ZoomIn,
                            contentDescription = "Zoom In",
                            tint = NeonCyan,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // TIMELINE TRACKS AREA WITH CENTER PLAYHEAD LINE
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(230.dp)
            ) {
                // Scrollable container containing ruler + tracks
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .horizontalScroll(scrollState)
                        .pointerInput(totalDurationMs, pxPerSecond) {
                            detectTapGestures { offset ->
                                val clickedMs = ((offset.x / pxPerSecond) * 1000L).toLong()
                                onSeekTo(clickedMs.coerceIn(0L, effectiveDurationMs))
                            }
                        }
                ) {
                    Column(
                        modifier = Modifier
                            .width(timelineWidthDp + containerWidthDp)
                            .fillMaxHeight()
                            .padding(start = centerLineDp, end = centerLineDp)
                    ) {
                        // 1. SECONDS RULER
                        TimelineRuler(
                            totalSeconds = totalSeconds,
                            pxPerSecond = pxPerSecond,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(26.dp)
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        // 2. VIDEO TRACK: THUMBNAIL STRIPS + ADD CLIP BUTTON
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(72.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            if (videoClips.isEmpty()) {
                                // Empty state placeholder clip
                                Box(
                                    modifier = Modifier
                                        .width(200.dp)
                                        .height(68.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(Color(0x1F00E5FF))
                                        .border(1.dp, NeonCyan.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                                        .clickable { onAddClip() },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Add, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Add Video Clip", fontSize = 12.sp, color = NeonCyanBright, fontWeight = FontWeight.Bold)
                                    }
                                }
                            } else {
                                videoClips.forEach { clip ->
                                    val isSelected = clip.id == selectedClipId
                                    val clipDurationSec = clip.durationMs / 1000f
                                    val clipWidthDp = (dpPerSecond * clipDurationSec).coerceAtLeast(70.dp)

                                    VideoClipThumbnailItem(
                                        clip = clip,
                                        widthDp = clipWidthDp,
                                        isSelected = isSelected,
                                        trimStartMs = if (isSelected) trimStartMs else 0L,
                                        trimEndMs = if (isSelected) trimEndMs else clip.durationMs,
                                        totalClipDurationMs = clip.durationMs,
                                        onSelect = { onSelectClip(clip) },
                                        onRemove = { onRemoveClip(clip.id) },
                                        onTrimDrag = { start, end -> onTrimChange(start, end) }
                                    )
                                }
                            }

                            // Big "+" Button at the end of clips to add more videos
                            Box(
                                modifier = Modifier
                                    .size(68.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0x2200E5FF))
                                    .border(1.2.dp, NeonCyanBright, RoundedCornerShape(12.dp))
                                    .clickable {
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        onAddClip()
                                    }
                                    .testTag("timeline_add_video_clip_button"),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = "Add Video",
                                        tint = NeonCyanBright,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Text(
                                        text = "Add",
                                        style = TextStyle(
                                            fontFamily = FontFamily.SansSerif,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 10.sp,
                                            color = NeonCyanBright
                                        )
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        // 3. AUDIO TRACK (Below Video)
                        AudioTrackRow(
                            audioTrackName = audioTrackName,
                            audioDurationMs = audioDurationMs,
                            onAddAudio = onAddAudio,
                            onRemoveAudio = onRemoveAudio,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(32.dp)
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        // 4. TEXT OVERLAYS TRACK (Below Audio)
                        TextTrackRow(
                            textOverlays = textOverlays,
                            onAddText = onAddText,
                            onRemoveText = onRemoveText,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(32.dp)
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        // 5. STICKERS TRACK (Below Text)
                        StickersTrackRow(
                            placedStickers = placedStickers,
                            onAddSticker = onAddSticker,
                            onRemoveSticker = onRemoveSticker,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(32.dp)
                        )
                    }
                }

                // FIXED WHITE PLAYHEAD LINE IN THE MIDDLE OF THE SCREEN
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .width(2.dp)
                        .align(Alignment.Center)
                        .background(Color.White)
                        .border(0.5.dp, Color(0xFF00E5FF).copy(alpha = 0.5f))
                        .testTag("timeline_playhead_line")
                ) {
                    // Top Playhead Handle Diamond / Marker
                    Canvas(
                        modifier = Modifier
                            .size(12.dp)
                            .align(Alignment.TopCenter)
                            .offset(y = (-2).dp)
                    ) {
                        drawCircle(color = Color.White, radius = size.minDimension / 2)
                    }
                }
            }
        }
    }
}

/**
 * Seconds Ruler: Ticks and time labels (00:00, 00:01, 00:02...)
 */
@Composable
private fun TimelineRuler(
    totalSeconds: Float,
    pxPerSecond: Float,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val count = totalSeconds.toInt() + 2
        for (sec in 0..count) {
            val x = sec * pxPerSecond

            // Major second tick
            drawLine(
                color = Color.White.copy(alpha = 0.65f),
                start = Offset(x, 14f),
                end = Offset(x, size.height),
                strokeWidth = 1.8f
            )

            // Sub-second tick (0.5s)
            val halfX = x + (pxPerSecond / 2f)
            drawLine(
                color = Color.White.copy(alpha = 0.3f),
                start = Offset(halfX, 20f),
                end = Offset(halfX, size.height),
                strokeWidth = 1f
            )
        }
    }

    // Overlay text numbers at second marks
    Row(modifier = modifier) {
        val count = totalSeconds.toInt() + 2
        val density = LocalDensity.current
        val dpPerSec = with(density) { pxPerSecond.toDp() }

        for (sec in 0..count) {
            Box(
                modifier = Modifier
                    .width(dpPerSec)
                    .height(26.dp),
                contentAlignment = Alignment.TopStart
            ) {
                Text(
                    text = String.format(Locale.US, "%02d:%02d", sec / 60, sec % 60),
                    style = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White.copy(alpha = 0.75f)
                    ),
                    modifier = Modifier.padding(start = 2.dp)
                )
            }
        }
    }
}

/**
 * Individual Video Clip item on timeline with thumbnail preview and edge trimming handles
 */
@Composable
private fun VideoClipThumbnailItem(
    clip: VideoClipItem,
    widthDp: androidx.compose.ui.unit.Dp,
    isSelected: Boolean,
    trimStartMs: Long,
    trimEndMs: Long,
    totalClipDurationMs: Long,
    onSelect: () -> Unit,
    onRemove: () -> Unit,
    onTrimDrag: (startMs: Long, endMs: Long) -> Unit
) {
    val haptic = LocalHapticFeedback.current
    var currentStartMs by remember(trimStartMs) { mutableStateOf(trimStartMs) }
    var currentEndMs by remember(trimEndMs) { mutableStateOf(trimEndMs) }

    Box(
        modifier = Modifier
            .width(widthDp)
            .height(68.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF1E2630))
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) NeonCyanBright else Color(0x3500E5FF),
                shape = RoundedCornerShape(8.dp)
            )
            .clickable {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onSelect()
            }
            .testTag("timeline_clip_${clip.id}")
    ) {
        // Thumbnail image
        if (clip.thumbnail != null) {
            Image(
                bitmap = clip.thumbnail,
                contentDescription = clip.name,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color(0xFF0F172A), Color(0xFF1E293B))
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = clip.name.take(12),
                    style = TextStyle(
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 10.sp,
                        color = TextMuted
                    )
                )
            }
        }

        // Clip duration badge
        Box(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(4.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(Color.Black.copy(alpha = 0.75f))
                .padding(horizontal = 4.dp, vertical = 1.dp)
        ) {
            val durSec = clip.durationMs / 1000f
            Text(
                text = String.format(Locale.US, "%.1fs", durSec),
                style = TextStyle(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 9.sp,
                    color = Color.White
                )
            )
        }

        // Close/Remove Button if selected
        if (isSelected) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(3.dp)
                    .size(20.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.8f))
                    .clickable { onRemove() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Remove Clip",
                    tint = CyberPink,
                    modifier = Modifier.size(12.dp)
                )
            }

            // LEFT TRIM HANDLE
            Box(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .fillMaxHeight()
                    .width(14.dp)
                    .background(NeonCyanBright)
                    .pointerInput(clip.durationMs) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            val deltaSec = dragAmount.x / 40f
                            val deltaMs = (deltaSec * 1000).toLong()
                            currentStartMs = (currentStartMs + deltaMs).coerceIn(0L, currentEndMs - 500L)
                            onTrimDrag(currentStartMs, currentEndMs)
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Text("◀", fontSize = 8.sp, color = Color.Black, fontWeight = FontWeight.ExtraBold)
            }

            // RIGHT TRIM HANDLE
            Box(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .fillMaxHeight()
                    .width(14.dp)
                    .background(NeonCyanBright)
                    .pointerInput(clip.durationMs) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            val deltaSec = dragAmount.x / 40f
                            val deltaMs = (deltaSec * 1000).toLong()
                            currentEndMs = (currentEndMs + deltaMs).coerceIn(currentStartMs + 500L, totalClipDurationMs)
                            onTrimDrag(currentStartMs, currentEndMs)
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Text("▶", fontSize = 8.sp, color = Color.Black, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

/**
 * Audio Track Row below the video track
 */
@Composable
private fun AudioTrackRow(
    audioTrackName: String?,
    audioDurationMs: Long,
    onAddAudio: () -> Unit,
    onRemoveAudio: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (audioTrackName != null) {
        Row(
            modifier = modifier
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF0F382A))
                .border(1.dp, CyberGreen, RoundedCornerShape(8.dp))
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.MusicNote,
                    contentDescription = "Audio",
                    tint = CyberGreen,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = audioTrackName.take(24),
                    style = TextStyle(
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = Color(0xFFE0FFE5)
                    )
                )
            }

            Box(
                modifier = Modifier
                    .size(18.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.6f))
                    .clickable { onRemoveAudio() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Remove Audio",
                    tint = Color.White,
                    modifier = Modifier.size(12.dp)
                )
            }
        }
    } else {
        Box(
            modifier = modifier
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0x0A06D6A0))
                .border(0.8.dp, CyberGreen.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                .clickable { onAddAudio() }
                .padding(horizontal = 10.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Add, contentDescription = null, tint = CyberGreen, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("+ Audio Track", fontSize = 10.5.sp, color = CyberGreen, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/**
 * Text Overlays Track Row
 */
@Composable
private fun TextTrackRow(
    textOverlays: List<TextOverlayItem>,
    onAddText: () -> Unit,
    onRemoveText: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    if (textOverlays.isNotEmpty()) {
        Row(
            modifier = modifier,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            textOverlays.forEach { textItem ->
                Row(
                    modifier = Modifier
                        .height(28.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF332608))
                        .border(1.dp, Color(0xFFFFB703), RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.TextFields,
                        contentDescription = "Text",
                        tint = Color(0xFFFFB703),
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = textItem.text.take(15),
                        style = TextStyle(
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.5.sp,
                            color = Color(0xFFFFE8A3)
                        )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Delete Text",
                        tint = Color(0xFFFFB703),
                        modifier = Modifier
                            .size(12.dp)
                            .clickable { onRemoveText(textItem.id) }
                    )
                }
            }

            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0x15FFB703))
                    .border(0.8.dp, Color(0xFFFFB703), RoundedCornerShape(6.dp))
                    .clickable { onAddText() },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Add, contentDescription = null, tint = Color(0xFFFFB703), modifier = Modifier.size(14.dp))
            }
        }
    } else {
        Box(
            modifier = modifier
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0x0AFFB703))
                .border(0.8.dp, Color(0xFFFFB703).copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                .clickable { onAddText() }
                .padding(horizontal = 10.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Add, contentDescription = null, tint = Color(0xFFFFB703), modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("+ Text Track", fontSize = 10.5.sp, color = Color(0xFFFFB703), fontWeight = FontWeight.Bold)
            }
        }
    }
}

/**
 * Stickers Track Row
 */
@Composable
private fun StickersTrackRow(
    placedStickers: List<PlacedStickerItem>,
    onAddSticker: () -> Unit,
    onRemoveSticker: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    if (placedStickers.isNotEmpty()) {
        Row(
            modifier = modifier,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            placedStickers.forEach { stickerItem ->
                Row(
                    modifier = Modifier
                        .height(28.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF2E103A))
                        .border(1.dp, Color(0xFFC77DFF), RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = stickerItem.sticker.displayIcon, fontSize = 12.sp)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = stickerItem.sticker.label.take(12),
                        style = TextStyle(
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.5.sp,
                            color = Color(0xFFE8C5FF)
                        )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Delete Sticker",
                        tint = Color(0xFFC77DFF),
                        modifier = Modifier
                            .size(12.dp)
                            .clickable { onRemoveSticker(stickerItem.id) }
                    )
                }
            }

            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0x15C77DFF))
                    .border(0.8.dp, Color(0xFFC77DFF), RoundedCornerShape(6.dp))
                    .clickable { onAddSticker() },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Add, contentDescription = null, tint = Color(0xFFC77DFF), modifier = Modifier.size(14.dp))
            }
        }
    } else {
        Box(
            modifier = modifier
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0x0AC77DFF))
                .border(0.8.dp, Color(0xFFC77DFF).copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                .clickable { onAddSticker() }
                .padding(horizontal = 10.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Add, contentDescription = null, tint = Color(0xFFC77DFF), modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("+ Stickers Track", fontSize = 10.5.sp, color = Color(0xFFC77DFF), fontWeight = FontWeight.Bold)
            }
        }
    }
}
