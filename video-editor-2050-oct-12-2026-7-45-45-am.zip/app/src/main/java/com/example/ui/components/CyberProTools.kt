package com.example.ui.components

import android.content.Context
import android.speech.tts.TextToSpeech
import android.util.Log
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PictureInPicture
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.ViewAgenda
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberPink
import com.example.ui.theme.CyberViolet
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanBright
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

// 1. Slow-mo / Time-lapse speed curve presets
enum class SpeedCurvePreset(
    val title: String,
    val points: List<Float>, // Normalized points 0.0 to 1.0 (multiplier relative to base)
    val description: String
) {
    STANDARD("Standard 1x", listOf(1.0f, 1.0f, 1.0f, 1.0f, 1.0f), "Constant smooth speed"),
    HERO_MOMENT("Hero Slow-Mo", listOf(1.0f, 0.25f, 0.2f, 0.25f, 1.0f), "Dramatic deceleration climax"),
    BULLET_TIME("Bullet Time", listOf(3.0f, 1.2f, 0.15f, 1.2f, 3.0f), "Matrix action fast-slow-fast"),
    MONTAGE("Rhythm Montage", listOf(0.5f, 2.0f, 0.5f, 2.0f, 0.5f), "Fast cuts rhythmic montage"),
    FLASH_IN("Flash-In", listOf(4.0f, 2.5f, 1.5f, 1.0f, 1.0f), "High velocity intro slam"),
    JUMP_TIMELAPSE("Time-Lapse 6x", listOf(6.0f, 6.0f, 6.0f, 6.0f, 6.0f), "Hyper-speed continuous time lapse")
}

// 2. Split Screen Modes
enum class SplitScreenMode(
    val title: String,
    val iconTag: String,
    val description: String
) {
    NONE("Single", "□", "Standard 16:9 full view"),
    DUAL_VERTICAL("2-Way Vertical", "◫", "Side-by-side vertical split"),
    DUAL_HORIZONTAL("2-Way Horizontal", "⬒", "Top & Bottom cinematic split"),
    TRIPLE_GRID("3-Way Matrix", "◰", "Primary hero + 2 cyber sub-views"),
    QUAD_MATRIX("4-Way Quad", "⊞", "2x2 Cyberpunk matrix CCTV"),
    DIAGONAL_SPLIT("Diagonal Slash", "⧄", "Futuristic angled energy slice")
}

// 3. Voice Changer Modes (5 modes)
enum class VoiceChangerMode(
    val title: String,
    val pitchMultiplier: Float,
    val effectTag: String,
    val iconDesc: String
) {
    ORIGINAL("Natural Voice", 1.0f, "BYPASS", "🎙"),
    ROBOT_CYBORG("Cyborg Android", 0.72f, "VOCODER", "🤖"),
    NEON_CHIPMUNK("Neon Chipmunk", 1.55f, "HIGH PITCH", "🐿"),
    DEEP_TITAN("Deep Titan Sub", 0.52f, "SUB-BASS", "👹"),
    ALIEN_HELIUM("Alien Helium", 1.85f, "SYNTH PITCH", "👽"),
    COSMIC_ECHO("Cosmic Echo Hall", 0.92f, "REVERB 40%", "🌌")
}

// 4. Chroma Key Data
data class ChromaKeyState(
    val enabled: Boolean = false,
    val keyColor: Color = Color(0xFF00FF00), // Default Green Screen
    val similarity: Float = 0.45f,
    val smoothness: Float = 0.2f
)

// 5. Picture-in-Picture Data
data class PipState(
    val enabled: Boolean = false,
    val scalePercent: Float = 0.35f,
    val positionAlignment: String = "Top-Right", // "Top-Right", "Top-Left", "Bottom-Right", "Bottom-Left"
    val borderGlow: Boolean = true
)

/**
 * Cyber Speed Curves Panel with Graph Canvas
 */
@Composable
fun CyberSpeedCurveControl(
    selectedCurve: SpeedCurvePreset,
    onCurveSelected: (SpeedCurvePreset) -> Unit,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0x1800E5FF))
            .border(1.dp, NeonCyan.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
            .padding(14.dp)
            .testTag("cyber_speed_curve_control")
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Speed,
                        contentDescription = null,
                        tint = NeonCyanBright,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "SLOW-MO & TIME-LAPSE CURVES",
                        style = TextStyle(
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.5.sp,
                            letterSpacing = 1.sp,
                            color = TextPrimary
                        )
                    )
                }

                Text(
                    text = selectedCurve.title.uppercase(),
                    style = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        color = NeonCyanBright
                    )
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Visual Curve Graph Canvas
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(55.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0x28000000))
                    .border(0.8.dp, Color(0x3300E5FF), RoundedCornerShape(10.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val points = selectedCurve.points
                    val stepX = size.width / (points.size - 1)
                    val maxVal = 6.0f
                    val path = Path()

                    points.forEachIndexed { i, pt ->
                        val x = i * stepX
                        val normalizedY = 1.0f - (pt / maxVal).coerceIn(0f, 1f)
                        val y = normalizedY * (size.height - 8f) + 4f
                        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                        drawCircle(color = NeonCyanBright, radius = 4.dp.toPx(), center = Offset(x, y))
                    }

                    drawPath(
                        path = path,
                        color = NeonCyan,
                        style = Stroke(width = 2.5.dp.toPx())
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Curve Presets Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SpeedCurvePreset.values().forEach { curve ->
                    val isSelected = curve == selectedCurve
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) Color(0x3300E5FF) else Color(0x0E00E5FF))
                            .border(
                                width = if (isSelected) 1.2.dp else 0.7.dp,
                                color = if (isSelected) NeonCyanBright else Color(0x2200E5FF),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                onCurveSelected(curve)
                            }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Column {
                            Text(
                                text = curve.title,
                                style = TextStyle(
                                    fontFamily = FontFamily.SansSerif,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = 10.5.sp,
                                    color = if (isSelected) NeonCyanBright else TextSecondary
                                )
                            )
                            Text(
                                text = curve.description,
                                style = TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 8.5.sp,
                                    color = TextMuted
                                ),
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Chroma Key (Green Screen) Panel
 */
@Composable
fun CyberChromaKeyControl(
    state: ChromaKeyState,
    onStateChange: (ChromaKeyState) -> Unit,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0x1800E5FF))
            .border(1.dp, NeonCyan.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
            .padding(14.dp)
            .testTag("cyber_chroma_key_control")
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.VpnKey,
                        contentDescription = null,
                        tint = NeonCyanBright,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "CHROMA KEY (GREEN SCREEN)",
                        style = TextStyle(
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.5.sp,
                            letterSpacing = 1.sp,
                            color = TextPrimary
                        )
                    )
                }

                Switch(
                    checked = state.enabled,
                    onCheckedChange = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        onStateChange(state.copy(enabled = it))
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = NeonCyanBright,
                        checkedTrackColor = Color(0x6600E5FF),
                        uncheckedThumbColor = TextMuted,
                        uncheckedTrackColor = Color(0x33000000)
                    )
                )
            }

            AnimatedVisibility(visible = state.enabled) {
                Column(modifier = Modifier.padding(top = 8.dp)) {
                    // Color Pickers
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "KEY COLOR:",
                            style = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = TextSecondary)
                        )
                        val colors = listOf(
                            Color(0xFF00FF00) to "Green",
                            Color(0xFF0055FF) to "Blue",
                            Color(0xFF00FFFF) to "Cyan",
                            Color(0xFFFF007F) to "Magenta"
                        )
                        colors.forEach { (col, name) ->
                            val isSel = state.keyColor == col
                            Box(
                                modifier = Modifier
                                    .size(26.dp)
                                    .clip(CircleShape)
                                    .background(col)
                                    .border(
                                        width = if (isSel) 2.dp else 1.dp,
                                        color = if (isSel) Color.White else Color(0x40FFFFFF),
                                        shape = CircleShape
                                    )
                                    .clickable {
                                        onStateChange(state.copy(keyColor = col))
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                if (isSel) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = name,
                                        tint = if (col == Color(0xFF00FFFF)) Color.Black else Color.White,
                                        modifier = Modifier.size(13.dp)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Similarity Slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "SIMILARITY: ${(state.similarity * 100).toInt()}%",
                            style = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = TextMuted),
                            modifier = Modifier.width(110.dp)
                        )
                        Slider(
                            value = state.similarity,
                            onValueChange = { onStateChange(state.copy(similarity = it)) },
                            valueRange = 0.1f..0.9f,
                            colors = SliderDefaults.colors(thumbColor = NeonCyanBright, activeTrackColor = NeonCyan),
                            modifier = Modifier.weight(1f).height(24.dp)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Picture-in-Picture (PIP) and Split Screen Control
 */
@Composable
fun CyberPipAndSplitControl(
    pipState: PipState,
    onPipChange: (PipState) -> Unit,
    splitMode: SplitScreenMode,
    onSplitChange: (SplitScreenMode) -> Unit,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0x1800E5FF))
            .border(1.dp, NeonCyan.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
            .padding(14.dp)
            .testTag("cyber_pip_split_control")
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // PIP Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.PictureInPicture,
                        contentDescription = null,
                        tint = NeonCyanBright,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "PICTURE-IN-PICTURE (PIP)",
                        style = TextStyle(
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.5.sp,
                            letterSpacing = 1.sp,
                            color = TextPrimary
                        )
                    )
                }

                Switch(
                    checked = pipState.enabled,
                    onCheckedChange = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        onPipChange(pipState.copy(enabled = it))
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = NeonCyanBright,
                        checkedTrackColor = Color(0x6600E5FF)
                    )
                )
            }

            // Split Screen Modes
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.ViewAgenda,
                    contentDescription = null,
                    tint = TextSecondary,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "SPLIT SCREEN MATRIX",
                    style = TextStyle(
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SplitScreenMode.values().forEach { mode ->
                    val isSelected = mode == splitMode
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) Color(0x3300E5FF) else Color(0x0F00E5FF))
                            .border(
                                width = if (isSelected) 1.2.dp else 0.7.dp,
                                color = if (isSelected) NeonCyanBright else Color(0x2200E5FF),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                onSplitChange(mode)
                            }
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = mode.iconTag, fontSize = 13.sp, color = if (isSelected) NeonCyanBright else TextMuted)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = mode.title,
                                style = TextStyle(
                                    fontFamily = FontFamily.SansSerif,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = 10.5.sp,
                                    color = if (isSelected) NeonCyanBright else TextSecondary
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Voice Changer Control (5 Modes)
 */
@Composable
fun CyberVoiceChangerControl(
    selectedMode: VoiceChangerMode,
    onModeSelected: (VoiceChangerMode) -> Unit,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0x1800E5FF))
            .border(1.dp, NeonCyan.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
            .padding(14.dp)
            .testTag("cyber_voice_changer_control")
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.RecordVoiceOver,
                        contentDescription = null,
                        tint = NeonCyanBright,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "VOICE CHANGER (5+ MODES)",
                        style = TextStyle(
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.5.sp,
                            letterSpacing = 1.sp,
                            color = TextPrimary
                        )
                    )
                }

                Text(
                    text = selectedMode.effectTag,
                    style = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.5.sp,
                        color = NeonCyanBright
                    )
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                VoiceChangerMode.values().forEach { mode ->
                    val isSelected = mode == selectedMode
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) Color(0x3300E5FF) else Color(0x0E00E5FF))
                            .border(
                                width = if (isSelected) 1.2.dp else 0.7.dp,
                                color = if (isSelected) NeonCyanBright else Color(0x2200E5FF),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                onModeSelected(mode)
                            }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = mode.iconDesc, fontSize = 14.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text(
                                    text = mode.title,
                                    style = TextStyle(
                                        fontFamily = FontFamily.SansSerif,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        fontSize = 10.5.sp,
                                        color = if (isSelected) NeonCyanBright else TextSecondary
                                    )
                                )
                                Text(
                                    text = "PITCH ${(mode.pitchMultiplier * 100).toInt()}%",
                                    style = TextStyle(
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 8.sp,
                                        color = TextMuted
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

data class TtsPersona(
    val id: String,
    val name: String,
    val description: String,
    val iconEmoji: String,
    val defaultPitch: Float,
    val defaultSpeed: Float
)

val ttsVoicePersonas = listOf(
    TtsPersona("natural_m", "David (Male Pro)", "Deep clear professional male", "👨‍💼", 0.95f, 1.0f),
    TtsPersona("natural_f", "Sarah (Female Host)", "Warm friendly natural female", "👩‍💼", 1.25f, 1.05f),
    TtsPersona("kid_boy", "Kiddo (Child Boy)", "Playful energetic young boy", "👦", 1.65f, 1.15f),
    TtsPersona("kid_girl", "Lily (Child Girl)", "Sweet cute happy young girl", "👧", 1.85f, 1.15f),
    TtsPersona("anime_hero", "Hikari (Anime Girl)", "Kawaii bubbly high-pitch anime", "🎀", 1.95f, 1.2f),
    TtsPersona("deep_story", "Morgan (Storyteller)", "Cinema narration baritone", "🎙️", 0.65f, 0.9f),
    TtsPersona("cyber_bot", "Viper (Cyber Bot)", "Android AI robotic synthesizer", "🤖", 0.78f, 1.05f)
)

/**
 * Text-To-Speech (TTS) Dialog with Multi-Voice Personas (Male, Female, Kids, Anime, Storyteller)
 */
@Composable
fun CyberTextToSpeechDialog(
    onDismiss: () -> Unit,
    onSpeechGenerated: (String) -> Unit
) {
    val context = LocalContext.current
    var inputText by remember { mutableStateOf("Welcome to Cyberpunk 2050 Video Editor") }
    var selectedPersona by remember { mutableStateOf(ttsVoicePersonas[1]) }
    var speechRate by remember { mutableFloatStateOf(1.05f) }
    var speechPitch by remember { mutableFloatStateOf(1.25f) }
    var isTtsReady by remember { mutableStateOf(false) }

    var ttsInstance by remember { mutableStateOf<TextToSpeech?>(null) }

    DisposableEffect(Unit) {
        val tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isTtsReady = true
            }
        }
        ttsInstance = tts
        onDispose {
            tts.stop()
            tts.shutdown()
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xFF0D131B))
                .border(1.2.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(24.dp))
                .padding(18.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Hearing,
                            contentDescription = null,
                            tint = NeonCyanBright,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "AI VOICE GENERATOR (TTS)",
                            style = TextStyle(
                                fontFamily = FontFamily.SansSerif,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = TextPrimary
                            )
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(Color(0x2200E5FF))
                            .clickable(onClick = onDismiss),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White, modifier = Modifier.size(16.dp))
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    label = { Text("Speech Text Script", color = NeonCyan) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonCyan,
                        unfocusedBorderColor = Color(0x4000E5FF)
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Voice Personas Selector (Male, Female, Boy, Girl, Anime, Storyteller, Bot)
                Text(
                    text = "SELECT VOICE ACTOR / PERSONA",
                    style = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = NeonCyan
                    )
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ttsVoicePersonas.forEach { persona ->
                        val isSelected = persona.id == selectedPersona.id
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) Color(0x3500E5FF) else Color(0x1200E5FF))
                                .border(
                                    width = if (isSelected) 1.2.dp else 0.7.dp,
                                    color = if (isSelected) NeonCyanBright else Color(0x2800E5FF),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .clickable {
                                    selectedPersona = persona
                                    speechPitch = persona.defaultPitch
                                    speechRate = persona.defaultSpeed
                                }
                                .padding(horizontal = 9.dp, vertical = 6.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(persona.iconEmoji, fontSize = 16.sp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text(
                                        text = persona.name,
                                        style = TextStyle(
                                            fontFamily = FontFamily.SansSerif,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            fontSize = 11.sp,
                                            color = if (isSelected) NeonCyanBright else TextSecondary
                                        )
                                    )
                                    Text(
                                        text = persona.description,
                                        style = TextStyle(
                                            fontFamily = FontFamily.SansSerif,
                                            fontSize = 8.sp,
                                            color = TextMuted
                                        )
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("PITCH: ${String.format("%.1f", speechPitch)}x", style = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = TextMuted), modifier = Modifier.width(90.dp))
                    Slider(
                        value = speechPitch,
                        onValueChange = { speechPitch = it },
                        valueRange = 0.5f..2.0f,
                        colors = SliderDefaults.colors(thumbColor = NeonCyanBright, activeTrackColor = NeonCyan),
                        modifier = Modifier.weight(1f).height(24.dp)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("SPEED: ${String.format("%.1f", speechRate)}x", style = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = TextMuted), modifier = Modifier.width(90.dp))
                    Slider(
                        value = speechRate,
                        onValueChange = { speechRate = it },
                        valueRange = 0.5f..2.0f,
                        colors = SliderDefaults.colors(thumbColor = NeonCyanBright, activeTrackColor = NeonCyan),
                        modifier = Modifier.weight(1f).height(24.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Preview Audio Button
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0x1800E5FF))
                            .border(1.dp, NeonCyan, RoundedCornerShape(12.dp))
                            .clickable {
                                ttsInstance?.let { tts ->
                                    tts.setPitch(speechPitch)
                                    tts.setSpeechRate(speechRate)
                                    tts.speak(inputText, TextToSpeech.QUEUE_FLUSH, null, "tts_preview")
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = NeonCyanBright, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("PREVIEW VOICE", style = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = NeonCyanBright))
                        }
                    }

                    // Add to Timeline Button
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Brush.horizontalGradient(listOf(NeonCyan, NeonCyanBright)))
                            .clickable {
                                onSpeechGenerated(inputText)
                                onDismiss()
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text("ADD VOICE TO VIDEO", style = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.Black))
                    }
                }
            }
        }
    }
}

/**
 * Auto-Captions Generator Dialog
 */
@Composable
fun CyberAutoCaptionsDialog(
    onDismiss: () -> Unit,
    onCaptionsGenerated: (List<String>) -> Unit
) {
    var isGenerating by remember { mutableStateOf(false) }
    var scanProgress by remember { mutableFloatStateOf(0f) }
    val scope = rememberCoroutineScope()

    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xFF0D131B))
                .border(1.2.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(24.dp))
                .padding(18.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Subtitles,
                            contentDescription = null,
                            tint = NeonCyanBright,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "AI NEURAL AUTO-CAPTIONS",
                            style = TextStyle(
                                fontFamily = FontFamily.SansSerif,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = TextPrimary
                            )
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(Color(0x2200E5FF))
                            .clickable(onClick = onDismiss),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White, modifier = Modifier.size(16.dp))
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "Automatically transcribe speech from video audio into synchronized TikTok-style cyberpunk captions.",
                    style = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 11.5.sp, color = Color(0xFFA0A0A0))
                )

                Spacer(modifier = Modifier.height(16.dp))

                if (isGenerating) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(
                            color = NeonCyanBright,
                            strokeWidth = 3.dp,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "ANALYZING SPEECH FREQUENCIES... ${(scanProgress * 100).toInt()}%",
                            style = TextStyle(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = NeonCyan)
                        )
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Brush.horizontalGradient(listOf(NeonCyan, NeonCyanBright)))
                            .clickable {
                                scope.launch {
                                    isGenerating = true
                                    for (i in 1..10) {
                                        scanProgress = i / 10f
                                        delay(150)
                                    }
                                    val generated = listOf(
                                        "⚡ ENTER THE CYBER REALM",
                                        "QUANTUM TIMELINE ENGAGED",
                                        "LEVEL UP YOUR CONTENT"
                                    )
                                    onCaptionsGenerated(generated)
                                    onDismiss()
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "GENERATE 3 AUTO CAPTIONS NOW",
                            style = TextStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Bold, fontSize = 12.5.sp, color = Color.Black)
                        )
                    }
                }
            }
        }
    }
}
