package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.SlowMotionVideo
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CosmicCyberBackground
import com.example.ui.components.GlassmorphicCard
import com.example.ui.components.GlassmorphismTemplatesButton
import com.example.ui.components.NeonGlowingTitle
import com.example.ui.components.NeonPulseNewProjectButton
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberViolet
import com.example.ui.theme.DarkCosmic
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanBright
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(
    onNavigateToEditor: () -> Unit = {},
    onNavigateToLogin: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var systemStatusMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(systemStatusMessage) {
        if (systemStatusMessage != null) {
            delay(2800)
            systemStatusMessage = null
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DarkCosmic)
            .testTag("home_screen_root")
    ) {
        // Deep cosmic cyber background with glow and grid
        CosmicCyberBackground()

        // Content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(scrollState)
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 480.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Top Cyber HUD Status bar
                TopCyberHudBar(onNavigateToLogin = onNavigateToLogin)

                Spacer(modifier = Modifier.height(36.dp))

                // App title "VIDEO EDITOR 2050" - Minimalist premium style with no glow
                NeonGlowingTitle(
                    title = "VIDEO EDITOR 2050",
                    modifier = Modifier.padding(horizontal = 8.dp)
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Subtitle: light gray (#A0A0A0), no glow
                Text(
                    text = "AI Powered • Pro Level • Next Gen",
                    style = TextStyle(
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.Normal,
                        fontSize = 13.5.sp,
                        letterSpacing = 1.4.sp,
                        color = Color(0xFFA0A0A0),
                        textAlign = TextAlign.Center
                    )
                )

                Spacer(modifier = Modifier.height(36.dp))

                // Glassmorphism Card: Quantum Timeline Engine overview
                GlassmorphicCard(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0x2600E5FF)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Memory,
                                        contentDescription = "Neural Engine",
                                        tint = NeonCyanBright,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "QUANTUM WORKSPACE",
                                        style = TextStyle(
                                            fontFamily = FontFamily.SansSerif,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            letterSpacing = 1.2.sp,
                                            color = TextPrimary
                                        )
                                    )
                                    Text(
                                        text = "NEURAL TIMELINE ACTIVE",
                                        style = TextStyle(
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Normal,
                                            fontSize = 10.sp,
                                            letterSpacing = 0.8.sp,
                                            color = NeonCyan
                                        )
                                    )
                                }
                            }

                            // Live pulse status chip
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0x2400FF9D))
                                    .border(1.dp, CyberGreen.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .clip(CircleShape)
                                            .background(CyberGreen)
                                    )
                                    Spacer(modifier = Modifier.width(5.dp))
                                    Text(
                                        text = "READY",
                                        style = TextStyle(
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 9.sp,
                                            color = CyberGreen
                                        )
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // High-tech Cyberpunk Quantum Timeline Hero Banner Image
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(130.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .border(1.dp, NeonCyan.copy(alpha = 0.45f), RoundedCornerShape(14.dp))
                        ) {
                            Image(
                                painter = painterResource(id = com.example.R.drawable.img_quantum_banner_1791686675432),
                                contentDescription = "Quantum Holographic Timeline Banner",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                            // Ambient gradient overlay to seamlessly blend with cyber card
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.verticalGradient(
                                            listOf(
                                                Color.Transparent,
                                                Color(0xCC040D18)
                                            )
                                        )
                                    )
                            )
                            // Subtle corner badge
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .padding(8.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xD905101A))
                                    .border(0.8.dp, NeonCyanBright, RoundedCornerShape(6.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "QUANTUM TIMELINE v2.5",
                                    style = TextStyle(
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 8.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = NeonCyanBright
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Features glass row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FeatureBadge(
                                icon = Icons.Default.Videocam,
                                label = "8K 120 FPS",
                                modifier = Modifier.weight(1f)
                            )
                            FeatureBadge(
                                icon = Icons.Default.AutoAwesome,
                                label = "AI VFX Gen",
                                modifier = Modifier.weight(1f)
                            )
                            FeatureBadge(
                                icon = Icons.Default.SlowMotionVideo,
                                label = "Zero Lag",
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // Bottom Action Section: NEW PROJECT & TEMPLATES buttons
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 480.dp)
                    .padding(top = 36.dp, bottom = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Feedback badge
                AnimatedVisibility(
                    visible = systemStatusMessage != null,
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    Box(
                        modifier = Modifier
                            .padding(bottom = 16.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0x3300E5FF))
                            .border(1.dp, NeonCyan, RoundedCornerShape(12.dp))
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = systemStatusMessage ?: "",
                            style = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.sp,
                                letterSpacing = 1.sp,
                                color = NeonCyanBright
                            )
                        )
                    }
                }

                // Big glowing "NEW PROJECT" button in neon cyan with subtle pulse animation (20dp corners)
                NeonPulseNewProjectButton(
                    onClick = {
                        systemStatusMessage = "INITIATING 2050 PROJECT MATRIX..."
                        onNavigateToEditor()
                    }
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Secondary button "TEMPLATES" with glassmorphism style (20dp corners)
                GlassmorphismTemplatesButton(
                    onClick = {
                        systemStatusMessage = "LOADING HOLOGRAPHIC TEMPLATES..."
                        scope.launch {
                            snackbarHostState.showSnackbar("Cyber Templates Loaded")
                        }
                    }
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Cyber footer
                Text(
                    text = "CYBERNETIC TIMELINE MATRIX • PRO VERSION 2050.4",
                    style = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Normal,
                        fontSize = 10.sp,
                        letterSpacing = 1.4.sp,
                        color = TextMuted,
                        textAlign = TextAlign.Center
                    )
                )
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(16.dp)
        )
    }
}

@Composable
private fun TopCyberHudBar(
    onNavigateToLogin: () -> Unit = {}
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(CyberGreen)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "GUEST // PROTOCOL ACTIVE",
                style = TextStyle(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    letterSpacing = 1.1.sp,
                    color = CyberGreen
                )
            )
        }

        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0x2600E5FF))
                .border(1.dp, NeonCyan, RoundedCornerShape(8.dp))
                .clickable {
                    onNavigateToLogin()
                }
                .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
            Text(
                text = "ACCOUNT",
                style = TextStyle(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    letterSpacing = 0.9.sp,
                    color = NeonCyanBright
                )
            )
        }
    }
}

@Composable
private fun FeatureBadge(
    icon: ImageVector,
    label: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0x1400E5FF))
            .border(0.8.dp, Color(0x3300E5FF), RoundedCornerShape(12.dp))
            .padding(vertical = 10.dp, horizontal = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = NeonCyan,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = label,
                style = TextStyle(
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 11.sp,
                    color = TextPrimary
                ),
                maxLines = 1
            )
        }
    }
}
